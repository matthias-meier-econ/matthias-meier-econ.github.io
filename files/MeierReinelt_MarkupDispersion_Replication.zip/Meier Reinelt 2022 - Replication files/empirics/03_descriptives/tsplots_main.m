clear all
close all
clc

addpath('functions')

data = load_data('../B_temp/tsdata_macromicro.csv',datenum('1995q1','yyyyQQ'),datenum('2017q3','yyyyQQ'),false);
time = datenum(data.date_quarterly, 'yyyyQQ');

col1 = [0 0 0];
col2 = [1 1 1]*0.4;
col3 = [1 1 1]*0.5;
col4 = [1 1 1]*0.8;

%% === Figure 1 === %%

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;

hold on
plot(time,data.lmarkup_PF_w4_var,'-','Color',col1,'Linewidth',4)
plot(time,data.lmarkup_PF_w2_var,'--','Color',col2,'Linewidth',4)
plot(time,data.lmarkup_AP_w4_var,':','Color',col3,'Linewidth',2)
plot(time,data.lmarkup_UC_w4_var,'-.','Color',col4,'Linewidth',2)
hold off

ylim([0 .125])
recessionplot
datetick('x', 'yyyy','keeplimits')
xlim([time(1) time(end)])
xlabel(' ')

legend('Baseline markups (within 4d-industry-quarters)',...
    'Baseline markups (within 2d-industry-quarters)',...
    'Accounting profits approach',...
    'User cost approach', ...
     'Interpreter','Latex','Location','Southoutside','Fontsize',20); 

my_fn_print(fig,['''../C_results/Figure1'''],'pdf')
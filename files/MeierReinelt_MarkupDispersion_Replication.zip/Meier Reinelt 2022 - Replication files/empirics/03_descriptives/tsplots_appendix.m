clear all
close all
clc

addpath('functions')

data = load_data('../B_temp/tsdata_macromicro.csv',datenum('1995q1','yyyyQQ'),datenum('2017q3','yyyyQQ'),false);
time = datenum(data.date_quarterly, 'yyyyQQ');

col1 = [0 0 0];
col2 = [1 1 1]*0.4;
col3 = [1 1 1]*0.5;
col4 = [1 1 1]*0.8;

%% === Figure A1(a) === %%

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;

hold on
plot(time,data.ffr3shockTightWeighted*100,'-','Color',col1,'Linewidth',3)
plot(time,data.policyShockTightWeighted*100,'--','Color',col2,'Linewidth',3)
plot(time,data.ffr3shockTightAllWeighted*100,':','Color',col3,'Linewidth',3)
plot(time,zeros(size(time)),'-','Color',col1,'Linewidth',1)
hold off

ylim([-40 20])
yticks([-40 -20 0 20])

recessionplot
datetick('x', 'yyyy','keeplimits')
xlim([time(1) time(end)])
xlabel(' ')

legend('Three-months federal funds future surprises', ... 
    '''Policy indicator'' of future surprises', ...
    'Unscheduled meetings and calls included', ...
    'Interpreter','Latex','Location','Southwest'); 

my_fn_print(fig,['''../C_results/FigureA1a'''],'pdf')

%% === Figure A1(b) === %%

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;

hold on
plot(time,data.ffr3shockTightSignWeighted*100,'-','Color',col1,'Linewidth',3)
plot(time,data.ffr3shockTightGBWeiUncorr*100,'--','Color',col2,'Linewidth',3)
plot(time,data.ffr3shockTightNoQEWeighted*100,':','Color',col3,'Linewidth',3)
plot(time,zeros(size(time)),'-','Color',col1,'Linewidth',1)
hold off

ylim([-40 20])
yticks([-40 -20 0 20])

recessionplot
datetick('x', 'yyyy','keeplimits')
xlim([time(1) time(end)])
xlabel(' ')

legend('Sign-restricted stock market comovement', ...
    'Purged of Greenbook forecasts', ...
    'QE announcements excluded', ... 
    'Interpreter','Latex','Location','Southwest'); 

my_fn_print(fig,['''../C_results/FigureA1b'''],'pdf')

%% === Figure A.1(c) === %%

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;

hold on
plot(time,data.lmarkup_PF_sga_w4_var,'-','Color',col1,'Linewidth',3)
plot(time,data.lmarkup_PF_TL_w4_var,'--','Color',col2,'Linewidth',3)
plot(time,data.lmarkup_PF_CS_w4_var,':','Color',col3,'Linewidth',3)

ylim([0 .15]) 

yyaxis right
plot(time,data.mshare4t_var,'-.','Color',col4,'Linewidth',3)
hold off

ax=gca;ax.YAxis(2).Color=[0 0 0];

recessionplot
datetick('x', 'yyyy','keeplimits')
xlim([time(1) time(end)])
xlabel(' ')

legend('Markups with SGA',...
    '4d-Translog markups',...
    '4d-cost shares markups',...
    'Market shares (RHS)', ...
     'Interpreter','Latex','Location','Northwest'); 

my_fn_print(fig,['''../C_results/FigureA1c'''],'pdf')

%% === Figure A.1(d) === %%

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;

hold on
plot(time,data.logTFP,'-','Color',col1,'Linewidth',3)
plot(time,data.logTFPUtil,'--','Color',col2,'Linewidth',3)
plot(time,data.logLaborProd,':','Color',col3,'Linewidth',3)
hold off

yticks([0.7:0.1:1.2])
ylim([0.7  1.2])

recessionplot
datetick('x', 'yyyy','keeplimits')
xlim([time(1) time(end)])
xlabel(' ')

legend('TFP',...
    'Util-adj. TFP',...
    'Labor productivity',...
     'Interpreter','Latex','Location','Northwest'); 

my_fn_print(fig,['''../C_results/FigureA1d'''],'pdf')
 clear all
close all
clc

addpath('functions')

lw = 4; % general line width
alpha = 0.15; % shading of bands
lwo = 1; % outer line width
lwl = 3; % legend line width

col1 = [0 0 0];
col2 = [1 1 1]*0.4;
col3 = [1 1 1]*0.5;

%% === Figure 4(a) === %%
result1 = readtable('../C_results/_Figure4a-1.csv');
result2 = readtable('../C_results/_Figure4a-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure4a'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure 4(b) === %%
result1 = readtable('../C_results/_Figure4b-1.csv');
result2 = readtable('../C_results/_Figure4b-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure4b'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure 4(c) === %%
result1 = readtable('../C_results/_Figure4c-1.csv');
result2 = readtable('../C_results/_Figure4c-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('p.p.','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Northwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure4c'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure 4(d) === %%
result1 = readtable('../C_results/_Figure4d-1.csv');
result2 = readtable('../C_results/_Figure4d-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Accounting profit markups','User cost approach markups','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure4d'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure C.9(c) === %%
result1 = readtable('../C_results/_FigureC9c-1.csv');
result2 = readtable('../C_results/_FigureC9c-2.csv');

norm = 1/7.1543; % implies 30bp response of one-year rate
fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],norm*result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],norm*result1.irf+norm*1.64*result1.irfse,norm*result1.irf-norm*1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],norm*result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],norm*result2.irf+norm*1.64*result2.irfse,norm*result2.irf-norm*1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC9c'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure C.9(d) === %%
result1 = readtable('../C_results/_FigureC9d-1.csv');
result2 = readtable('../C_results/_FigureC9d-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('p.p.','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Northwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC9d'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.1(a) === %%
result1 = readtable('../C_results/_FigureD1a-1.csv');
result2 = readtable('../C_results/_FigureD1a-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD1a'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.1(b) === %%
result1 = readtable('../C_results/_FigureD1b-1.csv');
result2 = readtable('../C_results/_FigureD1b-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD1b'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.1(c) === %%
result1 = readtable('../C_results/_FigureD1c-1.csv');
result2 = readtable('../C_results/_FigureD1c-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD1c'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.1(d) === %%
result1 = readtable('../C_results/_FigureD1d-1.csv');
result2 = readtable('../C_results/_FigureD1d-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD1d'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.1(e) === %%
result1 = readtable('../C_results/_FigureD1e-1.csv');
result2 = readtable('../C_results/_FigureD1e-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD1e'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.1(f) === %%
result1 = readtable('../C_results/_FigureD1f-1.csv');
result2 = readtable('../C_results/_FigureD1f-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD1f'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.2(a) === %%
result1 = readtable('../C_results/_FigureD2a-1.csv');
result2 = readtable('../C_results/_FigureD2a-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD2a'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.2(b) === %%
result1 = readtable('../C_results/_FigureD2b-1.csv');
result2 = readtable('../C_results/_FigureD2b-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD2b'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.2(c) === %%
result1 = readtable('../C_results/_FigureD2c-1.csv');
result2 = readtable('../C_results/_FigureD2c-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD2c'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.2(c) === %%
result1 = readtable('../C_results/_FigureD2d-1.csv');
result2 = readtable('../C_results/_FigureD2d-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD2d'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.2(e) === %%
result1 = readtable('../C_results/_FigureD2e-1.csv');
result2 = readtable('../C_results/_FigureD2e-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD2e'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.2(f) === %%
result1 = readtable('../C_results/_FigureD2f-1.csv');
result2 = readtable('../C_results/_FigureD2f-2.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo) 

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Higher implied price duration','Lower price adjustment frequency','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD2f'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.3(a)1 === %

result1 = readtable('../C_results/_FigureD3a1-1.csv');
result2 = readtable('../C_results/_FigureD3a1-2.csv');
result3 = readtable('../C_results/_FigureD3a1-3.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo)  

plot([0:16],result3.irf,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],result3.irf+1.64*result3.irfse,result3.irf-1.64*result3.irfse,col3,'--',0,lwo)  

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.2 0.4])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Three-months federal funds futures surprise',...
    '''Policy indicator'' of future surprises',...
    'Unscheduled meetings and calls included',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD3a1'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.3(a)2 === %

result1 = readtable('../C_results/_FigureD3a2-1.csv');
result2 = readtable('../C_results/_FigureD3a2-2.csv');
result3 = readtable('../C_results/_FigureD3a2-3.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo)  

plot([0:16],result3.irf,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],result3.irf+1.64*result3.irfse,result3.irf-1.64*result3.irfse,col3,'--',0,lwo)  

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.2 0.4])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Purged of Greenbook forecasts',...
    'Sign-restricted stock market comovement',...
    'QE announcements excluded',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD3a2'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.3(b)1 === %

result1 = readtable('../C_results/_FigureD3b1-1.csv');
result2 = readtable('../C_results/_FigureD3b1-2.csv');
result3 = readtable('../C_results/_FigureD3b1-3.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo)  

plot([0:16],result3.irf,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],result3.irf+1.64*result3.irfse,result3.irf-1.64*result3.irfse,col3,'--',0,lwo)  

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.2 0.4])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Three-months federal funds futures surprise',...
    '''Policy indicator'' of future surprises',...
    'Unscheduled meetings and calls included',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD3b1'''],'pdf')
clearvars -except data lw* alpha col*

%% === Figure D.3(b)2 === %

result1 = readtable('../C_results/_FigureD3b2-1.csv');
result2 = readtable('../C_results/_FigureD3b2-2.csv');
result3 = readtable('../C_results/_FigureD3b2-3.csv');

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],result1.irf,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],result1.irf+1.64*result1.irfse,result1.irf-1.64*result1.irfse,col1,'-',alpha,0)

plot([0:16],result2.irf,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],result2.irf+1.64*result2.irfse,result2.irf-1.64*result2.irfse,col2,'--',0,lwo)  

plot([0:16],result3.irf,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],result3.irf+1.64*result3.irfse,result3.irf-1.64*result3.irfse,col3,'--',0,lwo)  

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.2 0.4])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Purged of Greenbook forecasts',...
    'Sign-restricted stock market comovement',...
    'QE announcements excluded',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureD3b2'''],'pdf')
clearvars -except data lw* alpha col*
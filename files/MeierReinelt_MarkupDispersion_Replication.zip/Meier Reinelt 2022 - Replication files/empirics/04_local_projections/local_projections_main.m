clear all
close all
clc

addpath('functions')

data = load_data('../B_temp/tsdata_macromicro.csv',datenum('1995q1','yyyyQQ'),datenum('2017q3','yyyyQQ'),true);

lw = 4; % general line width
alpha = 0.15; % shading of bands
lwo = 1; % outer line width
lwl = 3; % legend line width

col1 = [0 0 0];
col2 = [1 1 1]*0.4;
col3 = [1 1 1]*0.5;

%% === Figure 2(a) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.002 0.003])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure2a'''],'pdf')
clearvars -except data lw* col* alpha 

%% === Figure 2(b) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure2b'''],'pdf')
clearvars -except data lw* col* alpha 

%% === Figure 2(c) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_AP_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_UC_w4_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Accounting profits approach','User cost approach','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure2c'''],'pdf')
clearvars -except data lw* col* alpha 

%% === Figure 2(d) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_sga_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_CS_w4_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Baseline with SGA','Cost shares','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure2d'''],'pdf')
clearvars -except data lw* col* alpha 

%% === Figure 3(a) === %

[irf1, irfse1] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFP,data.ffr3shockTightWeighted);
[irf3, irfse3] = estimate_lp(100*data.logLaborProd,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Util.-adjusted TFP','TFP','Labor Productivity','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure3a'''],'pdf')
clearvars -except data lw* col* alpha 

%% === Figure 3(b) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightWeighted);
irf2 = estimate_lp(100*-3/2*data.lmarkup_PF_w4_var,data.ffr3shockTightWeighted);
irf3 = estimate_lp(100*-6/2*data.lmarkup_PF_w4_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Util.-adjusted TFP','TFP implied by markup dispersion, $\eta = 3$','TFP implied by markup dispersion, $\eta = 6$','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/Figure3b'''],'pdf')
clearvars -except data lw* col* alpha 
function data = load_data(path,startDate,endDate,excludeGreatRecession);

%% Settings
finCrisDates = datenum(['2008q3'; '2008q4';'2009q1'; '2009q2'],'yyyyQQ')';

%% Load data
data = readtable(path); 
serialDateNumbers = datenum(data.date_quarterly, 'yyyyQQ');
data = data(serialDateNumbers >= startDate & serialDateNumbers <= endDate,:);
serialDateNumbers = serialDateNumbers(serialDateNumbers >= startDate & serialDateNumbers <= endDate,:);

%% Create gap at Financial Crisis
if excludeGreatRecession
tsample = length(serialDateNumbers);
aux = any(serialDateNumbers == finCrisDates,2).*(1:tsample)';
aux = aux(aux~=0);
t1 = min(aux);
t2 = max(aux);

% create gap
twedge = 4*10;
tsample2 = tsample+twedge;
date_quarterly = (1:tsample2)';

data2 = [data; data];
data2(tsample2+1:end,:) = [];

for tt=1:twedge 
    data2(tsample+tt,1) =  {'NaN'};
end     

% NaN for wedge period
for i=2:size(data2,2)
    data2(t1:t2+twedge,i) = table(NaN);
end
data2(t1:t2+twedge,1) = {'NaN'};

% Data after wedge period 
for i=1:size(data2,2)
    data2(t2+twedge+1:end,i) = data(t2+1:end,i);
end

% overwrite
data = data2;
end

end
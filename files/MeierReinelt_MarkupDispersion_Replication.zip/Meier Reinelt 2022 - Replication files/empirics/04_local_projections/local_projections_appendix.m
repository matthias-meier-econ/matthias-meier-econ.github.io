clear all
close all
clc

addpath('functions')

data = load_data('../B_temp/tsdata_macromicro.csv',datenum('1995q1','yyyyQQ'),datenum('2017q3','yyyyQQ'),true);
data_pre_GR = load_data('../B_temp/tsdata_macromicro.csv',datenum('1995q1','yyyyQQ'),datenum('2008q2','yyyyQQ'),false);
data_incl_GR = load_data('../B_temp/tsdata_macromicro.csv',datenum('1995q1','yyyyQQ'),datenum('2017q3','yyyyQQ'),false);

lw = 4; % general line width
alpha = 0.15; % shading of bands
lwo = 1; % outer line width
lwl = 3; % legend line width

col1 = [0 0 0];
col2 = [1 1 1]*0.4;
col3 = [1 1 1]*0.5;

%% === Figure B.1 === %%

[irf1, irfse1] = estimate_lp(100*data.logRND,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-3 -2 -1 0 1])
ylim([-3 1])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex') 

my_fn_print(fig,['''../C_results/FigureB1'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure B.2(a) === %%

% see Figure 3(a)

%% === Figure B.2(b) === %%

[irf1, irfse1] = estimate_lp(100*data.logGDP,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logY,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-2 -1 0])
ylim([-2.5 0.5])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('GDP','Business Output','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureB2b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure B.2(c) === %%

[irf1, irfse1] = estimate_lp(100*data.logUtil,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logK,data.ffr3shockTightWeighted);
[irf3, irfse3] = estimate_lp(100*data.logLq,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1.5 -1 -0.5 0 0.5])
ylim([-1.5 0.5])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Utilization','Capital','Quality-adjusted hours','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureB2c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure B.2(d) === %%

[irf1, irfse1] = estimate_lp_level(data.FFR,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp_level(data.GS1,data.ffr3shockTightWeighted);
[irf3, irfse3] = estimate_lp_level(data.GS2,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-0.75 -0.5 -0.25 0 0.25 0.5])
ylim([-0.8 0.5])

ylabel('p.p.','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Federal funds rate','One-year Treasury rate','Two-year Treasury rate','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureB2d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.1(a) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_AP_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_AP_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC1a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.1(b) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_UC_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_UC_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC1b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.1(c) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_TL_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_TL_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off 

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC1c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.1(d) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_CS_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_CS_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off 

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC1d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.1(e) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_sga_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_sga_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off 

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC1e'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.1(f) === %%

[irf1, irfse1] = estimate_lp(data.mshare4t_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.mshare2t_var*100,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off 

ylim([-0.0004 0.0008])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC1f'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.2(a) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_AP_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_AP_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC2a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.2(b) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_UC_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_UC_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC2b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.2(c) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_TL_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_TL_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC2c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.2(d) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_CS_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_CS_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC2d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.2(e) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_sga_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_sga_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC2e'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.2(f) === %%

[irf1, irfse1] = estimate_lp(data.mshare2t_var*100,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.mshare2t_var*100,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC2f'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.3(a) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_lowsales_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_lowsales_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC3a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.3(b) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_excgro_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_excgro_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC3b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.3(c) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_tr1_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_tr1_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC3c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.3(d) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_min16_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_min16_w2_var,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC3d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.3(e) === %%

[irf1, irfse1] = estimate_lp(data_pre_GR.lmarkup_PF_w4_var,data_pre_GR.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data_pre_GR.lmarkup_PF_w2_var,data_pre_GR.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC3e'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.3(f) === %%

[irf1, irfse1] = estimate_lp(data_incl_GR.lmarkup_PF_w4_var,data_incl_GR.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data_incl_GR.lmarkup_PF_w2_var,data_incl_GR.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC3f'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha



%% === Figure C.4(a) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_lowsales_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_lowsales_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')

my_fn_print(fig,['''../C_results/FigureC4a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.4(b) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_excgro_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_excgro_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')

my_fn_print(fig,['''../C_results/FigureC4b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.4(c) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_tr1_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_tr1_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')

my_fn_print(fig,['''../C_results/FigureC4c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.4(d) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_min16_w4_var,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_min16_w4_var,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')

my_fn_print(fig,['''../C_results/FigureC4d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.4(e) === %%

[irf1, irfse1] = estimate_lp(data_pre_GR.lmarkup_PF_w4_var,data_pre_GR.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data_pre_GR.lmarkup_PF_w4_var,data_pre_GR.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC4e'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.4(f) === %%

[irf1, irfse1] = estimate_lp(data_incl_GR.lmarkup_PF_w4_var,data_incl_GR.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data_incl_GR.lmarkup_PF_w4_var,data_incl_GR.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')

my_fn_print(fig,['''../C_results/FigureC4f'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.5 === %%

[irf1, irfse1] = estimate_lp(100*data.lmarkup_PF_logN,data.ffr3shockTightWeighted); 

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],zeros(17,1),'k-')
hold off

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')

my_fn_print(fig,['''../C_results/FigureC5'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.6(a) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w2_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w2_var,data.policyShockTightWeighted);
[irf3, irfse3] = estimate_lp(data.lmarkup_PF_w2_var,data.ffr3shockTightAllWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.002 0.003])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Three-months federal funds futures surprise',...
    '''Policy indicator'' of future surprises',...
    'Unscheduled meetings and calls included',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC6a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.6(a) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w2_var,data.ffr3shockTightGBWeiUncorr);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w2_var,data.ffr3shockTightSignWeighted);
[irf3, irfse3] = estimate_lp(data.lmarkup_PF_w2_var,data.ffr3shockTightNoQEWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.002 0.003])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Purged of Greenbook forecasts',...
    'Sign-restricted stock market comovement',...
    'QE announcements excluded',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC6b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.6(c) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.policyShockTightWeighted);
[irf3, irfse3] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightAllWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.002 0.003])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Three-months federal funds futures surprise',...
    '''Policy indicator'' of future surprises',...
    'Unscheduled meetings and calls included',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC6c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.6(d) === %

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightGBWeiUncorr);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightSignWeighted);
[irf3, irfse3] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightNoQEWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylim([-0.002 0.003])

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Purged of Greenbook forecasts',...
    'Sign-restricted stock market comovement',...
    'QE announcements excluded',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC6d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.7(a) === %%

% see Figure 2(b)

%% === Figure C.7(b) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightGBWeiUncorrCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightGBWeiUncorrExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC7b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.7(c) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.policyShockTightWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.policyShockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC7c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.7(d) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightSignWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightSignWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC7d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.7(e) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightAllWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightAllWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC7e'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.7(f) === %%

[irf1, irfse1] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightNoQEWeightedCont);
[irf2, irfse2] = estimate_lp(data.lmarkup_PF_w4_var,data.ffr3shockTightNoQEWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC7f'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C8(a)1 === %

[irf1, irfse1] = estimate_lp(100*data.logTFP,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFP,data.policyShockTightWeighted);
[irf3, irfse3] = estimate_lp(100*data.logTFP,data.ffr3shockTightAllWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Three-months federal funds futures surprise',...
%     '''Policy indicator'' of future surprises',...
%     'Unscheduled meetings and calls included',...
%     'Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC8a1'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C8(a)2 === %

[irf1, irfse1] = estimate_lp(100*data.logTFP,data.ffr3shockTightGBWeiUncorr);
[irf2, irfse2] = estimate_lp(100*data.logTFP,data.ffr3shockTightSignWeighted);
[irf3, irfse3] = estimate_lp(100*data.logTFP,data.ffr3shockTightNoQEWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Purged of Greenbook forecasts',...
%     'Sign-restricted stock market comovement',...
%     'QE announcements excluded',...
%     'Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC8a2'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C8(b)1 === %

[irf1, irfse1] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFPUtil,data.policyShockTightWeighted);
[irf3, irfse3] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightAllWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Three-months federal funds futures surprise',...
%     '''Policy indicator'' of future surprises',...
%     'Unscheduled meetings and calls included',...
%     'Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC8b1'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C8(b)2 === %

[irf1, irfse1] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightGBWeiUncorr);
[irf2, irfse2] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightSignWeighted);
[irf3, irfse3] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightNoQEWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
% [~,h_obj] = legend('Purged of Greenbook forecasts',...
%     'Sign-restricted stock market comovement',...
%     'QE announcements excluded',...
%     'Interpreter','Latex','Fontsize',20,'Location','Southwest');
% set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC8b2'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 


%% === Figure C8(c)1 === %

[irf1, irfse1] = estimate_lp(100*data.logLaborProd,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logLaborProd,data.policyShockTightWeighted);
[irf3, irfse3] = estimate_lp(100*data.logLaborProd,data.ffr3shockTightAllWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Three-months federal funds futures surprise',...
    '''Policy indicator'' of future surprises',...
    'Unscheduled meetings and calls included',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC8c1'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C8(c)2 === %

[irf1, irfse1] = estimate_lp(100*data.logLaborProd,data.ffr3shockTightGBWeiUncorr);
[irf2, irfse2] = estimate_lp(100*data.logLaborProd,data.ffr3shockTightSignWeighted);
[irf3, irfse3] = estimate_lp(100*data.logLaborProd,data.ffr3shockTightNoQEWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Purged of Greenbook forecasts',...
    'Sign-restricted stock market comovement',...
    'QE announcements excluded',...
    'Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC8c2'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.9(a) === %%

%%% For LP-IV, normalize shock to 30bp peak GS1 effect
[irf0, irfse0] = estimate_lp_iv(data.GS1,data.GS1,data.ffr3shockTightWeighted);
norm = max(irf0)/0.3; % = 7.1543

[irf1, irfse1] = estimate_lp_iv(data.lmarkup_PF_w4_var,data.GS1,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp_iv(data.lmarkup_PF_w2_var,data.GS1,data.ffr3shockTightWeighted);

irf1 = irf1/norm;
irf2 = irf2/norm;
irfse1 = irfse1/norm;
irfse2 = irfse2/norm;

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('within 4d-industry-quarter','within 2d-industry-quarter','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC9a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.9(b) === %%

%%% For LP-IV, normalize shock to 30bp peak GS1 effect
[irf0, irfse0] = estimate_lp_iv(data.GS1,data.GS1,data.ffr3shockTightWeighted);
norm = max(irf0)/0.3;

[irf1, irfse1] = estimate_lp_iv(100*data.logTFPUtil,data.GS1,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp_iv(100*data.logTFP,data.GS1,data.ffr3shockTightWeighted);
[irf3, irfse3] = estimate_lp_iv(100*data.logLaborProd,data.GS1,data.ffr3shockTightWeighted);

irf1 = irf1/norm;
irf2 = irf2/norm;
irf3 = irf3/norm;
irfse1 = irfse1/norm;
irfse2 = irfse2/norm;
irfse3 = irfse3/norm;

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],irf3,':','Color',col3,'Linewidth',lw)
plot_fan([0:16],irf3+irfse3,irf3-irfse3,col3,':',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Util.-adjusted TFP','TFP','Labor Productivity','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC9b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha

%% === Figure C.11(a) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFPMarkupDLE,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFPUtilMarkupDLE,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Markup-adjusted TFP','Markup- and util.-adjusted TFP','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC11a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.11(b) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFPplus,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFPplusUtil,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

yticks([-1 -0.5 0])
ylim([-1.25 0.25])

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('TFP','Util.-adjusted TFP','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC11b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.11(c) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFPI,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFPIUtil,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('TFP in investment','Util.-adjusted TFP in investment','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC11c'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.11(d) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFPC,data.ffr3shockTightWeighted);
[irf2, irfse2] = estimate_lp(100*data.logTFPCUtil,data.ffr3shockTightWeighted);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('TFP in consumption','Util.-adjusted TFP in consumption','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC11d'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

%% === Figure C.12(a) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(100*data.logTFPUtil,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC12a'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 


%% === Figure C.12(b) === %%

[irf1, irfse1] = estimate_lp(100*data.logTFP,data.ffr3shockTightWeightedCont);
[irf2, irfse2] = estimate_lp(100*data.logTFP,data.ffr3shockTightWeightedExp);

fig = figure;

set(fig,'DefaultAxesFontSize',20);
grid on; box on;
xticks([0:4:16])
hYLabel = get(gca,'YLabel');
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.15, 0.5, 0]);
xlim([0 16])

hold on
plot([0:16],irf1,'-','Color',col1,'Linewidth',lw)
plot_fan([0:16],irf1+irfse1,irf1-irfse1,col1,'-',alpha,0)

plot([0:16],irf2,'--','Color',col2,'Linewidth',lw)
plot_fan([0:16],irf2+irfse2,irf2-irfse2,col2,'--',0,lwo)

plot([0:16],zeros(17,1),'k-')
hold off

ax = gca; 
ax.YAxis.Exponent = 0;

ylabel('\%','Interpreter','Latex')
xlabel('Quarters since shock','Interpreter','Latex')
[~,h_obj] = legend('Contractionary shock','Expansionary shock','Interpreter','Latex','Fontsize',20,'Location','Southwest');
set(findobj(h_obj,'type','line'),'linewidth',lwl);

my_fn_print(fig,['''../C_results/FigureC12b'''],'pdf')
clearvars -except data data_pre_GR data_incl_GR lw* col* alpha 

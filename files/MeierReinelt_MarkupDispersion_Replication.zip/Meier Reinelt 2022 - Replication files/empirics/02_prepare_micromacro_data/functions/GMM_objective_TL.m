function GMMObjective = GMM_objective_TL(params,data)

y_corr      = data(:,1);
v           = data(:,2);
k           = data(:,3);
Ly_corr     = data(:,4);
Lv          = data(:,5);
Lk          = data(:,6);  
L4v         = data(:,7);

productivity     = y_corr  - params(1) * v  - params(2) * k  - params(3) * v.^2  - params(4) * k.^2;
Lproductivity    = Ly_corr - params(1) * Lv - params(2) * Lk - params(3) * Lv.^2 - params(4) * Lk.^2;

[~, productivity_shock] = ols(productivity, [Lproductivity, Lproductivity.^2]); 
 
aux = [L4v L4v.^2 k k.^2].*productivity_shock;  
GMMObjective = length(aux)*mean(aux)*mean(aux)';    

end
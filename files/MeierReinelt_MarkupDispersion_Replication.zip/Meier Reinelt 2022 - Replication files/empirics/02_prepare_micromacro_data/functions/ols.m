function [betta, resid] = ols(y,X)
    X = [X ones(size(X,1),1)]; 
    betta = (X'*X)\(X'*y); 
%     betta = X\y; 
    resid = y - X*betta;
end
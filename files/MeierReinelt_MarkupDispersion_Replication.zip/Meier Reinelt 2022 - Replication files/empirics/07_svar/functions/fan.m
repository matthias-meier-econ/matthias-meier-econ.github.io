function fan(y,xHi,xLo,faceColor,linestyle,faceAlpha,edgeThick) 
if edgeThick > 0
    faceColorLight = (1-faceAlpha)*faceColor + faceAlpha*[1 1 1];
    plot(y,xHi,linestyle,'Color',faceColorLight,'Linewidth',edgeThick,'HandleVisibility','off') 
    plot(y,xLo,linestyle,'Color',faceColorLight,'Linewidth',edgeThick,'HandleVisibility','off')  
end
fill([y fliplr(y)],[xHi' fliplr(xLo')],'b',...
    'FaceColor',faceColor,'FaceAlpha',faceAlpha,'EdgeColor','none','HandleVisibility','off')
end
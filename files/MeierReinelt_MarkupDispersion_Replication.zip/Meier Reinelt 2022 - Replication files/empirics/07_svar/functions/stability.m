function d = stability(mAL, p)
% -------------------------------------------------------------------------
% Checks whether reduced-form VAR model is stable and print a warning 
% whenever the model is not stable.
% 
% Inputs:
% - mAL:    K x (p * K) Matrix of reduced-form VAR coefficients
% - p:      Number of lags in the VAR
% Outputs: 
% - d:      Largest eigenvalue in modulus
% -------------------------------------------------------------------------


%% Definitions
% Create companion form matrix
K = size(mAL, 1); 
mA_CF = [mAL; eye(K * (p - 1)), zeros(K * (p - 1), K)];
 

%% Eigenvalues
e = eigs(mA_CF, 1); % Only compute largest eigenvalue
d = abs(e); % Takes the modulus in case the eigenvalue is complex

end


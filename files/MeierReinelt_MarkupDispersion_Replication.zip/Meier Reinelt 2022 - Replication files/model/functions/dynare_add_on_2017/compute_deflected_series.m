function deflect_ = compute_deflected_series(M_,options_,deflect_,var_list_,plots)

T = options_.simul_length;

deflect_series{1}= deflect_.y_e * (M_.Sigma_e .* diag(randn(size(M_.Sigma_e,1),1)));

for i=2:T
   deflect_series{i}=deflect_.y_y*deflect_series{i-1} + deflect_.y_e * (M_.Sigma_e .* diag(randn(size(M_.Sigma_e,1),1)));
end

temp = cat(3,deflect_series{:});

for jj=1:M_.exo_nbr
    deflect_.series((jj-1)*M_.endo_nbr+[1:M_.endo_nbr],:)=squeeze(temp(:,jj,:));
end
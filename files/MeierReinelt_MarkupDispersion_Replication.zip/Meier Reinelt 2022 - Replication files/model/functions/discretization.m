% Discretize AR process of CPI

% Load data from FRED

% fredurl     = 'https://research.stlouisfed.org/fred2/';
% fredfetch   = fred(fredurl);
% startdate   = '01/01/1984';
% enddate     = '12/31/2018';
% sCPI        = fetch(fredfetch,'CPIAUCSL',startdate,enddate);
% close(fredfetch);
% save functions/fred_data.mat
load functions/fred_data.mat

% Estimate AR(1)
cpi     = sCPI.Data(3:3:end,2);
series  = log(cpi);
X       = [ones(size(series(1:end-1))) series(1:end-1)];
Y       = series(2:end);
coeff   = X\Y;
sig     = var(Y-X*coeff);

% Discretize
N        = 49; % grid points
M        = 1; 
A1bar    = 0; 
A2bar    = coeff(2); 
SIGMAbar = sig; 
[Pr_mat,Pr_mat_key,zbar] = fn_var_to_markov(1,A1bar,A2bar,SIGMAbar,N,1e3,1);
Pr_mat_key = [zeros(1,N); Pr_mat_key; zeros(1,N)];

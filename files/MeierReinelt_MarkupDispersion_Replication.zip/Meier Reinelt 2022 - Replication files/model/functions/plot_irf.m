function [ylim_out] = plot_irf(irf1, irf2, title, legendInPercent, legendOn, ylim_in)

if legendInPercent
    irf1 = irf1*100;
    irf2 = irf2*100;
end

col1 = [0 0 0];
col2 = [1 1 1]*0.4;

ls = 30; 
lw = 8;

set(0,'DefaultAxesFontSize',ls)
set(0,'DefaultTextFontSize',ls) 
 
h=figure;  
subplot('Position',[0.2 0.2 0.75 0.75]);

hold on
p1=plot([0:length(irf1)-1],[0:length(irf1)-1]*0,'k-');
p2=plot([0:length(irf1)-1],irf1,'-','color',col1,'LineWidth',lw);
p3=plot([0:length(irf2)-1],irf2,'--','color',col2,'LineWidth',lw);   
xlim([0 length(irf1)-1])
xticks(0:4:length(irf1))   
xlabel('Quarters since shock','Interpreter','Latex'); 

if legendInPercent; ylabel('\%','Interpreter','Latex'); end;

hYLabel = get(gca,'YLabel');
ax=gca;
ax.YRuler.Exponent = 0;

if nargin > 5
    ylim(ylim_in); 
end

set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.2, 0.5, 0]);

if legendOn
    if ~isempty(strfind(title, 'theta1')) 
        [h_legend,h_obj] = legend([p2,p3],{'$1-\theta_1 = 2.31\%$','$1 -\theta_1 =1 - \theta_2 = 6.78\%$'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'eta')) 
        [h_legend,h_obj] = legend([p2,p3],{'$\eta = 6$','$\eta = 12$'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'frisch')) 
        [h_legend,h_obj] = legend([p2,p3],{'$1/\varphi = 0.25$','$1/\varphi = 0.75$'},'Interpreter','Latex','FontSize',ls,'Location','Southeast');
    elseif ~isempty(strfind(title, 'tfp')) 
        [h_legend,h_obj] = legend([p2,p3],{'MP shock','TFP shock'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'taylor')) 
        [h_legend,h_obj] = legend([p2,p3],{'Baseline','Alternative Taylor rule'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'hetDet')) 
        [h_legend,h_obj] = legend([p2,p3],{'Contractionary MP shock','Expansionary MP shock'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'homDet')) 
        [h_legend,h_obj] = legend([p2,p3],{'Contractionary MP shock','Expansionary MP shock'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'trend_infl')) 
        [h_legend,h_obj] = legend([p2,p3],{'0\% annual','2\% annual'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    elseif ~isempty(strfind(title, 'simulated')) 
        [h_legend,h_obj] = legend([p2,p3],{'Baseline','LP on simulated data'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    end
    hL=findobj(h_obj,'type','line'); set(hL,'linewidth',3); 
end

% add numbering 1-5 for markups
if (strcmp(title, 'markups'))  
     
    for jj=1:5
        kk=jj+1;
        irf1(kk,6-jj);

        d = (irf1(kk+2,6-jj) - irf1(kk+1,6-jj));
        X = diff(get(gca, 'xlim'));
        Y = diff(get(gca, 'ylim'));
        p = pbaspect;
        a = atan(d*p(2)*X/p(1)/Y)*180/pi;
        
        text(jj+1, irf1(kk+1,6-jj), ['$' num2str(6-jj) '$'], 'BackgroundColor', 'w', 'rotation', a, 'Fontsize',24,'Interpreter','Latex'); %
    end
    
end

grid on; box on;

fn_print(h,['''output_figures/irf_' title '.pdf''']); 

ylim_out = ylim;

end




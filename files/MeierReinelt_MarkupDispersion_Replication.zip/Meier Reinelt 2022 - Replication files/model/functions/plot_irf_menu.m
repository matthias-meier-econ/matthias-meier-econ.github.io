function plot_irf_menu(var_x, var_y, title)

col1 = [0 0 0];
col2 = [1 1 1]*0.4;

ls = 30; 
lw = 8;
ls2 = 25;

set(0,'DefaultAxesFontSize',ls2)
set(0,'DefaultTextFontSize',ls2) 
 
h=figure;  
subplot('Position',[0.2 0.2 0.75 0.75]);
hold on

p1=plot([0 1],[0  0],'k-');
p2=plot(var_x,var_y,'-','color',col1,'LineWidth',lw);
xlim([0 1]); xticks(0:0.2:1); 
ylim([-0.1 0.6]); yticks(0:0.2:0.60); grid on
xlabel('Average price adjustment frequency','Interpreter','Latex'); 
ylabel('\%','Interpreter','Latex'); 
hYLabel = get(gca,'YLabel');
ax=gca;
ax.YRuler.Exponent = 0;
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
set(hYLabel, 'Units', 'Normalized', 'Position', [-0.18, 0.5, 0]);

grid on; box on;

fn_print(h,['''output_figures/' title '.pdf''']); 


end




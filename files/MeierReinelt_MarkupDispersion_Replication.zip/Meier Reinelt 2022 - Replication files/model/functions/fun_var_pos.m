%% Create markers for position of variables 

pos = struct;

for i=1:size(M_.endo_names,1)
    str = M_.endo_names(i,:);
    str = string(str);
    str = strtrim(str);

%     eval(join([str,'_pos=strmatch(''',str,''',M_.endo_names,''exact'');'],''))
    eval(join(['pos.' str,'=strmatch(''',str,''',M_.endo_names,''exact'');'],''))
end


% Baseline parameters

betta       = (1.03)^(-1/4);    % Discount factor
siggma      = 0.5;              % Elasticity of intertemporal substitution
eta         = 6;                % Elasticity of substitution between varieties
varphi      = 1/0.1135;         % Inverse Frisch elasticity

% Probability of non-adjustment
theta_1 = 1 - 0.0231;
theta_2 = 1 - 0.0678;
theta_3 = 1 - 0.1396;
theta_4 = 1 - 0.2829; 
theta_5 = 1 - 0.8470; 
theta   = (theta_1+theta_2+theta_3+theta_4+theta_5)/5;

phi_pi      = 1.50;             % Taylor coefficient on inflation
phi_y       = 0.05;             % Taylor coefficient on output gap
pibar       = 1.00;             % Trend inflation
rho_i       = 0.85;             % Interest rate smoothing
sig_eps_i   = 0.00411;          % Std of MP shock
rho_a       = 0.92;             % Persistence of tech shock
sig_eps_a   = 0.00001;          % Std of tech shock ~0
posmp       = 1;                % Indicator for sign of MP shock (1=positive, -1=negative shock to Taylor rule)


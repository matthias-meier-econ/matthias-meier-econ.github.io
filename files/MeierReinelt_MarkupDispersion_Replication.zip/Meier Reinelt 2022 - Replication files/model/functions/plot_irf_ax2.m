function [ylim_out] = plot_irf_ax2(irf1, irf2, title, legendInPercent, legendOn)

if legendInPercent
    irf1 = irf1*100;
    irf2 = irf2*100;
end

col1 = [0 0 0];
col2 = [1 1 1]*0.4;

ls = 30; 
lw = 8;

set(0,'DefaultAxesFontSize',ls)
set(0,'DefaultTextFontSize',ls) 
 
h=figure; 
set(h,'defaultAxesColorOrder',[ col2]); 
if legendInPercent; ylabel('\%','Interpreter','Latex'); end;
hYLabel = get(gca,'YLabel');
hold on
p1=plot([0:length(irf1)-1],[0:length(irf1)-1]*0,'k-');
p2=plot([0:length(irf1)-1],irf1,'-','color',col1,'LineWidth',lw);
yyaxis right
p3=plot([0:length(irf2)-1],irf2,'--','color',col2,'LineWidth',lw); 
xlim([0 length(irf1)-1])
xticks(0:4:length(irf1))   
xlabel('Quarters since shock','Interpreter','Latex'); 
ax=gca;
ax.YAxis(1).Exponent = 0;
ax.YAxis(2).Exponent = 0;
set(hYLabel,'rotation',0,'VerticalAlignment','middle')
if legendOn 
    if ~isempty(strfind(title, 'eta')) 
        [h_legend,h_obj] = legend([p2,p3],{'$\eta = 6$','$\eta = 12$'},'Interpreter','Latex','FontSize',ls,'Location','Southeast');
    elseif ~isempty(strfind(title, 'frisch')) 
        [h_legend,h_obj] = legend([p2,p3],{'$1/\varphi = 0.25$','$1/\varphi = 0.75$'},'Interpreter','Latex','FontSize',ls,'Location','Southeast');
   elseif ~isempty(strfind(title, 'theta1')) 
        [h_legend,h_obj] = legend([p2,p3],{'$\theta_1 = 1 - 0.0231$','$\theta_1 = \theta_2 =1 - 0.0678$'},'Interpreter','Latex','FontSize',ls,'Location','Southeast');
    elseif ~isempty(strfind(title, 'tfp')) 
        [h_legend,h_obj] = legend([p2,p3],{'MP shock','TFP shock'},'Interpreter','Latex','FontSize',ls,'Location','Northeast');
    end
    hL=findobj(h_obj,'type','line'); set(hL,'linewidth',3); 
end
grid on; box on; 

fn_print(h,['''output_figures/irf_' title '_ax2.pdf''']); 

ylim_out = ylim;

end
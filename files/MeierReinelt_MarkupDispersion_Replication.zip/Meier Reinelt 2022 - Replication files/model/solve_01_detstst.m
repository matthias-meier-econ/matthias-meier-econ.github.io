%% Solve model


% Positive MP shock
posmp = 1; % 1=positive MP shock, -1=negative MP shock

% Save parameters
cd   'model'
save paramfile sig_eps_i sig_eps_a betta siggma varphi eta ...
     theta_1 theta_2 theta_3 theta_4 theta_5 phi_pi phi_y pibar ...
     rho_a rho_i pbar_1 pbar_2 pbar_3 pbar_4 pbar_5 ...
     ybar mctildebar pstarbar_1 pstarbar_2 pstarbar_3 pstarbar_4 pstarbar_5 ...
     sbar_1 sbar_2 sbar_3 sbar_4 sbar_5 sbar ...
     markupbar_1 markupbar_2 markupbar_3 markupbar_4 markupbar_5 ...
     psibar_1 psibar_2 psibar_3 psibar_4 psibar_5 ...
     phibar_1 phibar_2 phibar_3 phibar_4 phibar_5 ...
     abar nbar tfpbar ibar i_annbar pi_annbar posmp


% Solve 2rd order approximation around deterministic steady state
order = 2;
dynare model_01_baseline.mod nograph -Dalternative_taylor_rule=0
cd ..


% Position of variables
fun_var_pos


% IRFs
pos.markupdisp = M_.endo_nbr+1;
irf_mp_pos_sss = NaN(M_.endo_nbr+2,17);
irf_mp_pos_sss(pos.i_ann,:) = oo_.irfs.i_ann_eps_i;
irf_mp_pos_sss(pos.y,:) = oo_.irfs.y_eps_i;
irf_mp_pos_sss(pos.tfp,:) = oo_.irfs.tfp_eps_i;
irf_mp_pos_sss(pos.s,:) = oo_.irfs.s_eps_i;
irf_mp_pos_sss(pos.n,:) = oo_.irfs.n_eps_i;
irf_mp_pos_sss(pos.mctilde,:) = oo_.irfs.mctilde_eps_i;
irf_mp_pos_sss(pos.markup_1,:) = oo_.irfs.markup_1_eps_i;
irf_mp_pos_sss(pos.markup_2,:) = oo_.irfs.markup_2_eps_i;
irf_mp_pos_sss(pos.markup_3,:) = oo_.irfs.markup_3_eps_i;
irf_mp_pos_sss(pos.markup_4,:) = oo_.irfs.markup_4_eps_i;
irf_mp_pos_sss(pos.markup_5,:) = oo_.irfs.markup_5_eps_i;
irf_mp_pos_sss(pos.markupdisp,:) = 2/eta*irf_mp_pos_sss(pos.s,:);




% Negative MP shock
posmp = - 1; % 1=positive MP shock, -1=negative MP shock

% Save parameters
cd   'model'
save paramfile sig_eps_i sig_eps_a betta siggma varphi eta ...
     theta_1 theta_2 theta_3 theta_4 theta_5 phi_pi phi_y pibar ...
     rho_a rho_i pbar_1 pbar_2 pbar_3 pbar_4 pbar_5 ...
     ybar mctildebar pstarbar_1 pstarbar_2 pstarbar_3 pstarbar_4 pstarbar_5 ...
     sbar_1 sbar_2 sbar_3 sbar_4 sbar_5 sbar ...
     markupbar_1 markupbar_2 markupbar_3 markupbar_4 markupbar_5 ...
     psibar_1 psibar_2 psibar_3 psibar_4 psibar_5 ...
     phibar_1 phibar_2 phibar_3 phibar_4 phibar_5 ...
     abar nbar tfpbar ibar i_annbar pi_annbar posmp

% Run risk-sensitive linear approximation 
order = 2;
dynare model_01_baseline.mod noclearall nograph -Dalternative_taylor_rule=0
cd ..

% Position of variables
fun_var_pos

% IRFs
pos.markupdisp = M_.endo_nbr+1;
irf_mp_neg_sss = NaN(M_.endo_nbr+2,17);
irf_mp_neg_sss(pos.i_ann,:) = oo_.irfs.i_ann_eps_i;
irf_mp_neg_sss(pos.y,:) = oo_.irfs.y_eps_i;
irf_mp_neg_sss(pos.tfp,:) = oo_.irfs.tfp_eps_i;
irf_mp_neg_sss(pos.s,:) = oo_.irfs.s_eps_i;
irf_mp_neg_sss(pos.n,:) = oo_.irfs.n_eps_i;
irf_mp_neg_sss(pos.mctilde,:) = oo_.irfs.mctilde_eps_i;
irf_mp_neg_sss(pos.markup_1,:) = oo_.irfs.markup_1_eps_i;
irf_mp_neg_sss(pos.markup_2,:) = oo_.irfs.markup_2_eps_i;
irf_mp_neg_sss(pos.markup_3,:) = oo_.irfs.markup_3_eps_i;
irf_mp_neg_sss(pos.markup_4,:) = oo_.irfs.markup_4_eps_i;
irf_mp_neg_sss(pos.markup_5,:) = oo_.irfs.markup_5_eps_i;
irf_mp_neg_sss(pos.markupdisp,:) = 2/eta*irf_mp_neg_sss(pos.s,:);








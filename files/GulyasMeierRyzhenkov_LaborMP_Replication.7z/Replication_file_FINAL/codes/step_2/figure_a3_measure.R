rm(list = ls()) 
library(dplyr)                                                                                                                             
library(haven)                                                                                                                              
library(foreign)                                                                                                                           
library(statar)                                                                                                                            
library(data.table)                                                                                                                        
library(statar)                                                                                                                            
library(zoo)                                                                                                                               
library(lubridate)                                                                                                                         
library(lfe)                                                                                                                               
library(parallel)                                                                                                                          
library(doParallel)                                                                                                                        
library(fixest)                                                                                                                            
library(tictoc)                                                                                                                            
library(tidyverse) 

# Define paths to data and code 
cd <- 
data_path   <- cd
code_path   <- paste0(cd,"codes/")
result_path   <- paste0(cd,"outputs/")    

H <- 12                                                                                                                                    
s <- 6                                                                                                                                     
num_tred <- 0                                                                                                                              
listofh <- 0:H                                                                                                                             
sho_na <- c("ois3_mq","mpp3_mq","mps3_mq","ois6_mq","mpp6_mq","mps6_mq")                                                                   
vars <- c("all","wage_all","female","firmTenure","nace1","firm_age","benr_akm","penr_akm","bluecollar","dailyWage","Qempdays","maxdays","wage_lag","firm_size","mkt_share","worker_age","match_akm")

source(paste0(code_path,"11_functions.R"))                                                                                                                                                                                                                      ###

data <- generate_data(akm_window="roll",akm_version="standard", shon=s, age_restriction = TRUE, var_add="none", fill=FALSE, User, data_path) %>% as.data.table()
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,t1 := data[list(penr,trend-1)][["empl"]]]

data <- generate_median(data,"benr_akm",0)
data <- generate_median(data,"penr_akm",0)

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_average.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$penr_akm_m==1)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_wrk_lo.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$penr_akm_m==2)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_wrk_hi.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$benr_akm_m==1)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_frm_lo.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$benr_akm_m==2)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_frm_hi.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$penr_akm_m==1 & data$benr_akm_m==1)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_wrk_lo_frm_lo.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$penr_akm_m==2 & data$benr_akm_m==1)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_wrk_hi_frm_lo.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$penr_akm_m==1 & data$benr_akm_m==2)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_wrk_lo_frm_hi.rds"))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  return(c(parameter,mean( filter(data,data$t1==1 & data$penr_akm_m==2 & data$benr_akm_m==2)$lhs, na.rm=T )))
  data <- subset(data,select=-c(lhs))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a3_unconditional_wrk_hi_frm_hi.rds"))


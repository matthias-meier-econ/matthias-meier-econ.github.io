rm(list = ls())                                                                                                                            
library(dplyr)                                                                                                                             
library(haven)                                                                                                                             
library(foreign)                                                                                                                           
library(statar)                                                                                                                            
library(data.table)                                                                                                                         
library(zoo)                                                                                                                               
library(lubridate)                                                                                                                         
library(lfe)                                                                                                                               
library(parallel)                                                                                                                          
library(doParallel)                                                                                                                        
library(fixest)                                                                                                                            
library(tictoc)                                                                                                                            
library(tidyverse) 

# Define paths to data and code 
cd <- 
data_path   <- cd
code_path   <- paste0(cd,"codes/")
result_path   <- paste0(cd,"outputs/")                

H <- 12                                                                                                                                    
s <- 6                                                                                                                                     
num_tred <- 0                                                                                                                              
listofh <- 0:H                                                                                                                             
sho_na <- c("ois3_mq","mpp3_mq","mps3_mq","ois6_mq","mpp6_mq","mps6_mq")                                                                   
vars <- c("all","wage_all","female","firmTenure","nace1","firm_age","benr_akm","penr_akm","bluecollar","dailyWage","Qempdays","maxdays","wage_lag","firm_size","mkt_share","worker_age","match_akm")

source(paste0(code_path,"11_functions.R"))                                                                                                                                                                                                                      ###


data <- generate_data(akm_window="roll",akm_version="standard", shon=s, age_restriction = TRUE, var_add="female", fill=FALSE, User, data_path) %>% as.data.table()
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,t1 := data[list(penr,trend-1)][["empl"]]]
data <- select(data,-c(benr))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  est<-feols(lhs ~ sho + trend | penr + quart, data=subset(data,data$t1 == 1 & data$female == 0), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a5_regression_panel_a",".rds"))


data <- generate_data(akm_window="roll",akm_version="standard", shon=s, age_restriction = TRUE, var_add="all", fill=TRUE, User, data_path) %>% as.data.table()
data <- select(data,-c(firmTenure,nace1,firm_age,bluecollar,Qempdays,maxdays,wage_lag,firm_size,mkt_share,worker_age,))
data <- select(data,-c(benr_akm,penr_akm))
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data$wor_per <- data$trend * data$empl
data <- data %>% group_by(penr) %>% mutate(wor_per_lag = lag(wor_per,1))
data$wor_per_lag <- ifelse( data$wor_per==1,0,data$wor_per_lag)
data$gap <- data$wor_per - data$wor_per_lag
data <- subset(data,data$gap==1)
data <- select(data,-c(wor_per,wor_per_lag,gap,nofill))
data <- data %>% as.data.table()
data$log_wage <- log(data$dailyWage)
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,t1 := data[list(penr,trend-1)][["empl"]]]
data <- select(data,-c(dailyWage,empl))
data[,b1 := data[list(penr,trend-1)][["benr"]]]

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["log_wage"]] - data[list(penr,trend-1)][["log_wage"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data$lhs <- ifelse(data$lhs2 == data$b1, data$lhs,NA)
  data <- subset(data,select=-c(lhs2))
  est<-feols(lhs ~ sho + trend | penr + quart, data=subset(data,data$t1 == 1 & data$female==0), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a5_regression_panel_b",".rds"))
rm(list = ls())                                                                                                                            
library(dplyr)                                                                                                                             
library(haven)                                                                                                                             
library(foreign)                                                                                                                           
library(statar)                                                                                                                            
library(data.table)                                                                                                                        
library(zoo)                                                                                                                               
library(lubridate)                                                                                                                         
library(lfe)                                                                                                                               
library(parallel)                                                                                                                          
library(doParallel)                                                                                                                        
library(fixest)                                                                                                                            
library(tictoc)                                                                                                                            
library(tidyverse) 

# Define paths to data and code 
cd <- 
data_path   <- cd
code_path   <- paste0(cd,"codes/")
result_path   <- paste0(cd,"outputs/")              
                                                                                                                                        
H <- 12                                                                                                                                    
s <- 6                                                                                                                                     
num_tred <- 0                                                                                                                              
listofh <- 0:H                                                                                                                             
sho_na <- c("ois3_mq","mpp3_mq","mps3_mq","ois6_mq","mpp6_mq","mps6_mq")                                                                   
vars <- c("all","wage_all","female","firmTenure","nace1","firm_age","benr_akm","penr_akm","bluecollar","dailyWage","Qempdays","maxdays","wage_lag","firm_size","mkt_share","worker_age","match_akm")

source(paste0(code_path,"11_functions.R"))                                                                                                                                                                                                                      ###

data <- generate_data(akm_window="const",akm_version="standard", shon=s, age_restriction = TRUE, var_add="all", fill=TRUE, User, data_path) %>% as.data.table()
data <- select(data,-c(female,firmTenure,nace1,firm_age,bluecollar,dailyWage,wage_lag,firm_size,mkt_share,worker_age))
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data$Qempdays <- as.numeric(data$Qempdays)
data$maxdays <- as.numeric(data$maxdays)
data$numQ <- data$maxdays
data$empQ <- data$Qempdays
data <- select(data,-c(Qempdays))
data <- data %>% group_by(trend) %>% mutate(numQm = mean(maxdays,na.rm = T))
data <- select(data,-c(maxdays))
data$numQm <- ifelse( is.nan(data$numQm)==T,90,data$numQm)
data$numQ <- ifelse(is.na(data$numQ)==T,data$numQm,data$numQ)
data <- select(data,-c(numQm))
data$empQ <- ifelse(is.na(data$empQ)==T & data$empl==0, 0        ,data$empQ)
data$empQ <- ifelse(is.na(data$empQ)==T & data$empl==1, data$numQ, data$empQ)
data$non_empl <- data$numQ - data$empQ
data <- select(data,-c(numQ,empQ))
data <- data %>% as.data.table()
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[, nonempl := cumsum(non_empl), by = penr]
data <- subset(data,data$nofill==1)
data <- select(data,-c(non_empl,nofill))  
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,t1 := data[list(penr,trend-1)][["empl"]]]
data[,b1 := data[list(penr,trend-1)][["benr"]]]
data[,n1 := data[list(penr,trend-1)][["nonempl"]]]
data <- generate_quintiles(data,"benr_akm",lag=1)
data <- generate_quintiles(data,"penr_akm",lag=1)
data <- select(data,-c(penr_akm))
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  cat(c("   h=", parameter))
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["benr_akm"]] - data[list(penr,trend-1)][["benr_akm"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data[,lhs3 := data[list(penr,trend+parameter)][["nonempl"]]] 
  data$lhs <- ifelse(data$lhs2 != data$b1,data$lhs,NA)
  data$lhs <- ifelse(data$lhs3 - data$n1 < 30,NA,data$lhs)
  data <- select(data, -c(lhs2,lhs3))
  est<-feols(lhs ~ sho + trend | penr + quart^benr_akm_q + quart^penr_akm_q, data=subset(data,data$t1==1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a6_regression_panel_a_1",".rds"))


results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  cat(c("   h=", parameter))
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["benr_akm"]] - data[list(penr,trend-1)][["benr_akm"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data[,lhs3 := data[list(penr,trend+parameter)][["nonempl"]]] 
  data$lhs <- ifelse(data$lhs2 != data$b1,data$lhs,NA)
  data$lhs <- ifelse(data$lhs3 - data$n1 >= 30,NA,data$lhs)
  data <- select(data, -c(lhs2,lhs3))
  est<-feols(lhs ~ sho + trend | penr + quart^benr_akm_q + quart^penr_akm_q, data=subset(data,data$t1==1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a6_regression_panel_a_2",".rds"))



data <- generate_data(akm_window="const",akm_version="standard", shon=s, age_restriction = TRUE, var_add="all", fill=TRUE, User, data_path) %>% as.data.table()
data <- select(data,-c(female,firmTenure,nace1,firm_age,bluecollar,dailyWage,wage_lag,firm_size,mkt_share,worker_age))
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data$Qempdays <- as.numeric(data$Qempdays)
data$maxdays <- as.numeric(data$maxdays)
data$numQ <- data$maxdays
data$empQ <- data$Qempdays
data <- select(data,-c(Qempdays))
data <- data %>% group_by(trend) %>% mutate(numQm = mean(maxdays,na.rm = T))
data <- select(data,-c(maxdays))
data$numQm <- ifelse( is.nan(data$numQm)==T,90,data$numQm)
data$numQ <- ifelse(is.na(data$numQ)==T,data$numQm,data$numQ)
data <- select(data,-c(numQm))
data$empQ <- ifelse(is.na(data$empQ)==T & data$empl==0, 0        ,data$empQ)
data$empQ <- ifelse(is.na(data$empQ)==T & data$empl==1, data$numQ, data$empQ)
data$non_empl <- data$numQ - data$empQ
data <- select(data,-c(numQ,empQ))
data <- data %>% as.data.table()
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[, nonempl := cumsum(non_empl), by = penr]
data <- subset(data,data$nofill==1)
data <- select(data,-c(non_empl,nofill))  
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,t1 := data[list(penr,trend-1)][["empl"]]]
data[,b1 := data[list(penr,trend-1)][["benr"]]]
data[,n1 := data[list(penr,trend-1)][["nonempl"]]]
data <- generate_quintiles(data,"benr_akm",lag=1)
data <- generate_quintiles(data,"penr_akm",lag=1)
data[,benr_akm_l := data[list(penr,trend-1)][["benr_akm"]]]
data[,penr_akm_l := data[list(penr,trend-1)][["penr_akm"]]]
data <- select(data,-c(penr_akm))
data$benr_akm_l <- (data$benr_akm_l - median(data$benr_akm_l,na.rm=T))/sd(data$benr_akm_l,na.rm=T)
data$penr_akm_l <- (data$penr_akm_l - median(data$penr_akm_l,na.rm=T))/sd(data$penr_akm_l,na.rm=T)
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)

results_l <- foreach(parameter = c(5,12), .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  cat(c("   h=", parameter))
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["benr_akm"]] - data[list(penr,trend-1)][["benr_akm"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data[,lhs3 := data[list(penr,trend+parameter)][["nonempl"]]] 
  data$lhs <- ifelse(data$lhs2 != data$b1,data$lhs,NA)
  data$lhs <- ifelse(data$lhs3 - data$n1 >= 30,NA,data$lhs)
  data <- select(data, -c(lhs2,lhs3))
  est<-feols(lhs ~ sho*benr_akm_l*penr_akm_l + trend | penr + quart^penr_akm_q + quart^benr_akm_q, data=subset(data,data$t1 == 1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a6_regression_panel_b",".rds"))

results_l <- foreach(parameter = 5, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  cat(c("   h=", parameter))
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["benr_akm"]] - data[list(penr,trend-1)][["benr_akm"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data[,lhs3 := data[list(penr,trend+parameter)][["nonempl"]]] 
  data$lhs <- ifelse(data$lhs2 != data$b1,data$lhs,NA)
  data$lhs <- ifelse(data$lhs3 - data$n1 >= 30,NA,data$lhs)
  data <- select(data, -c(lhs2,lhs3))
  est<-feols(lhs ~ sho*benr_akm_l*penr_akm_l + trend | penr + quart^penr_akm_q + quart^benr_akm_q, data=subset(data,data$t1 == 1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return( vcov(est) )
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a6_vcov_panel_b",".rds"))


results_l <- foreach(parameter = c(5,12), .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  cat(c("   h=", parameter))
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["benr_akm"]] - data[list(penr,trend-1)][["benr_akm"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data[,lhs3 := data[list(penr,trend+parameter)][["nonempl"]]] 
  data$lhs <- ifelse(data$lhs2 != data$b1,data$lhs,NA)
  data$lhs <- ifelse(data$lhs3 - data$n1 < 30,NA,data$lhs)
  data <- select(data, -c(lhs2,lhs3))
  est<-feols(lhs ~ sho*benr_akm_l*penr_akm_l + trend | penr + quart^penr_akm_q + quart^benr_akm_q, data=subset(data,data$t1 == 1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a6_regression_panel_c",".rds"))

results_l <- foreach(parameter = 5, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  cat(c("   h=", parameter))
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["benr_akm"]] - data[list(penr,trend-1)][["benr_akm"]] ]
  data[,lhs2 := data[list(penr,trend+parameter)][["benr"]]]
  data[,lhs3 := data[list(penr,trend+parameter)][["nonempl"]]] 
  data$lhs <- ifelse(data$lhs2 != data$b1,data$lhs,NA)
  data$lhs <- ifelse(data$lhs3 - data$n1 < 30,NA,data$lhs)
  data <- select(data, -c(lhs2,lhs3))
  est<-feols(lhs ~ sho*benr_akm_l*penr_akm_l + trend | penr + quart^penr_akm_q + quart^benr_akm_q, data=subset(data,data$t1 == 1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return( vcov(est) )
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a6_vcov_panel_c",".rds"))

rm(list = ls())                                                                            
library(dplyr)                                                                             
library(haven)                                                                             
library(foreign)                                                                           
library(statar)                                                                            
library(data.table)                                                                        
library(statar)                                                                            
library(zoo)                                                                               
library(lubridate)                                                                         
library(lfe)                                                                               
library(parallel)                                                                          
library(doParallel)                                                                        
library(fixest)                                                                            
library(tictoc)                                                                            
library(ggplot2) 
library(lmtest)
library(sandwich)

# Define paths to data and code 
cd <- 
data_path   <- cd
code_path   <- paste0(cd,"codes/")
result_path   <- paste0(cd,"outputs/")    
figure_path   <- paste0(cd,"figures/")   


listofh <- 0:12                                                                                                                             
sho_na <- c("ois3_mq","mpp3_mq","mps3_mq","ois6_mq","mpp6_mq","mps6_mq")                                                                   
s<-6

shocks <- read_dta(paste0(data_path,"shocks_quarterly_1999_2019.dta"))                                                                             
macro <- read_dta(paste0(data_path,"controls_1999_2019.dta"))
together <- cbind(macro,shocks)
together$quart <- rep(c(1,2,3,4),21)

datats1 <- ts(together$er1564 , start = c(1999,1) , frequency = 4)
datats2 <- ts(together$er2559  , start = c(1999,1) , frequency = 4)
decompose_beer1 = decompose(datats1, "additive")
adjust_beer1 = datats1 - decompose_beer1$seasonal
decompose_beer2 = decompose(datats2, "additive")
adjust_beer2 = datats2 - decompose_beer2$seasonal

datats3 <- ts(together$cpi , start = c(1999,1) , frequency = 4)
decompose_beer3 = decompose(datats3, "additive")
adjust_beer3 = datats3 - decompose_beer3$seasonal

together$er15a  <- as.vector(adjust_beer1)
together$er25a  <- as.vector(adjust_beer2)
together$cpi_a  <- as.vector(adjust_beer3)

together$sho<- together$mps6_mq/sd(together$mps6_mq, na.rm = T)                                                                                              
together <- together %>% as.data.table()                                                                                                         

together$sho1 <- lag(together$sho,n=1)
together$sho2 <- lag(together$sho,n=2)
together$sho3 <- lag(together$sho,n=3)
together$sho4 <- lag(together$sho,n=4)

together$log_gdp <- log(together$gdp)
together$log_gdp_1 <-  lag(together$log_gdp, n=1)
together$log_gdp_2 <-  lag(together$log_gdp, n=2)
together$log_gdp_3 <-  lag(together$log_gdp, n=3)
together$log_gdp_4 <-  lag(together$log_gdp, n=4)
together$log_gdp_5 <-  lag(together$log_gdp, n=5)
together$gdp_delta <- together$log_gdp - together$log_gdp_1
together$gdp_delta_1 <- together$log_gdp_1 - together$log_gdp_2
together$gdp_delta_2 <- together$log_gdp_2 - together$log_gdp_3
together$gdp_delta_3 <- together$log_gdp_3 - together$log_gdp_4
together$gdp_delta_4 <- together$log_gdp_4 - together$log_gdp_5

together$log_cpi <- log(together$cpi_a)
together$log_cpi_1 <-  lag(together$log_cpi, n=1)
together$log_cpi_2 <-  lag(together$log_cpi, n=2)
together$log_cpi_3 <-  lag(together$log_cpi, n=3)
together$log_cpi_4 <-  lag(together$log_cpi, n=4)
together$log_cpi_5 <-  lag(together$log_cpi, n=5)
together$cpi_delta <- together$log_cpi - together$log_cpi_1
together$cpi_delta_1 <- together$log_cpi_1 - together$log_cpi_2
together$cpi_delta_2 <- together$log_cpi_2 - together$log_cpi_3
together$cpi_delta_3 <- together$log_cpi_3 - together$log_cpi_4
together$cpi_delta_4 <- together$log_cpi_4 - together$log_cpi_5

together$er15_l1 <- lag(together$er15a,n=1)
together$er15_l2 <- lag(together$er15a,n=2)
together$er15_l3 <- lag(together$er15a,n=3)
together$er15_l4 <- lag(together$er15a,n=4)

together$er25_l1 <- lag(together$er25a,n=1)
together$er25_l2 <- lag(together$er25a,n=2)
together$er25_l3 <- lag(together$er25a,n=3)
together$er25_l4 <- lag(together$er25a,n=4)

# gdp
results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table')) %do% {
  together$lhs <-  lead(together$log_gdp, n=parameter) - lag(together$log_gdp, n=1) 
  est<-lm(data=together, lhs ~ sho + sho1 + gdp_delta_1 + gdp_delta_2 + gdp_delta_3 + gdp_delta_4 + cpi_delta_1 + cpi_delta_2 + cpi_delta_3 + cpi_delta_4 + er15_l1 + er15_l2 + er15_l3 + er15_l4 + factor(quart) + trend)
  return(c(parameter,est[["coefficients"]],coeftest(est, vcov = NeweyWest(est, lag = parameter + 1))[,2]))
}  
results_l <- results_l %>% as.data.frame()
rtos <- cbind(results_l[,1],results_l[,3],results_l[,22]) %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a2_regression_panel_a",".rds"))

# er 15+
results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table')) %do% {
  together$lhs <-  lead(together$er15a, n=parameter) 
  est<-lm(data=together, lhs ~ sho + sho1 + gdp_delta_1 + gdp_delta_2 + gdp_delta_3 + gdp_delta_4 + cpi_delta_1 + cpi_delta_2 + cpi_delta_3 + cpi_delta_4 + er15_l1 + er15_l2 + er15_l3 + er15_l4 + factor(quart) + trend)
  return(c(parameter,est[["coefficients"]],coeftest(est, vcov = NeweyWest(est, lag = parameter + 1))[,2]))
}  
results_l <- results_l %>% as.data.frame()
rtos <- cbind(results_l[,1],results_l[,3],results_l[,22]) %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a2_regression_panel_b",".rds"))

# er 25-59
results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table')) %do% {
  together$lhs <-  lead(together$er25a, n=parameter) 
  est<-lm(data=together, lhs ~ sho + sho1 + gdp_delta_1 + gdp_delta_2 + gdp_delta_3 + gdp_delta_4 + cpi_delta_1 + cpi_delta_2 + cpi_delta_3 + cpi_delta_4 + er15_l1 + er15_l2 + er15_l3 + er15_l4 + factor(quart) + trend)
  return(c(parameter,est[["coefficients"]],coeftest(est, vcov = NeweyWest(est, lag = parameter + 1))[,2]))
}  
results_l <- results_l %>% as.data.frame()
rtos <- cbind(results_l[,1],results_l[,3],results_l[,22]) %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a2_regression_panel_c",".rds"))

# cpi
results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table')) %do% {
  together$lhs <-  lead(together$log_cpi, n=parameter) - lag(together$log_cpi, n=1) 
  est<-lm(data=together, lhs ~ sho + sho1 + gdp_delta_1 + gdp_delta_2 + gdp_delta_3 + gdp_delta_4 + cpi_delta_1 + cpi_delta_2 + cpi_delta_3 + cpi_delta_4 + er15_l1 + er15_l2 + er15_l3 + er15_l4 + factor(quart) + trend)
  return(c(parameter,est[["coefficients"]],coeftest(est, vcov = NeweyWest(est, lag = parameter + 1))[,2]))
}  
results_l <- results_l %>% as.data.frame()
rtos <- cbind(results_l[,1],results_l[,3],results_l[,22]) %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a2_regression_panel_d",".rds"))

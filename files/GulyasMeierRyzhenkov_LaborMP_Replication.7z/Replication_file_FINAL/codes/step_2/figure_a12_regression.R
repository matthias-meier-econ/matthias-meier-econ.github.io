rm(list = ls())                                                                                                                            
library(dplyr)                                                                                                                             
library(haven)                                                                                                                             
library(foreign)                                                                                                                           
library(statar)                                                                                                                            
library(data.table)                                                                                                                        
library(statar)                                                                                                                            
library(zoo)                                                                                                                               
library(lubridate)                                                                                                                         
library(lfe)                                                                                                                               
library(parallel)                                                                                                                          
library(doParallel)                                                                                                                        
library(fixest)                                                                                                                            
library(tictoc)                                                                                                                            
library(tidyverse) 
                                                                                                               
# Define paths to data and code 
cd <- 
data_path   <- cd
code_path   <- paste0(cd,"codes/")
result_path   <- paste0(cd,"outputs/")                    

H <- 12                                                                                                                                    
s <- 6                                                                                                                                     
num_tred <- 0                                                                                                                              
listofh <- 0:H                                                                                                                             
sho_na <- c("ois3_mq","mpp3_mq","mps3_mq","ois6_mq","mpp6_mq","mps6_mq")                                                                   
vars <- c("all","wage_all","female","firmTenure","nace1","firm_age","benr_akm","penr_akm","bluecollar","dailyWage","Qempdays","maxdays","wage_lag","firm_size","mkt_share","worker_age","match_akm")

source(paste0(code_path,"11_functions.R"))                                                                                                                                                                                                                      ###

data <- generate_data(akm_window="roll",akm_version="standard", shon=s, age_restriction = TRUE, var_add="female", fill=TRUE, User, data_path) %>% as.data.table()
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,t1 := data[list(penr,trend-1)][["empl"]]]
data <- select(data,-c(benr))

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  est<-feols(lhs ~ sho + trend | penr + quart, data=subset(data,data$t1 == 1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a12_regression_panel_a",".rds"))

data <- generate_quintiles(data,"benr_akm",lag=0)
data <- generate_quintiles(data,"penr_akm",lag=0)
data$benr_akm <- (data$benr_akm - median(data$benr_akm,na.rm=T))/sd(data$benr_akm,na.rm=T)
data$penr_akm <- (data$penr_akm - median(data$penr_akm,na.rm=T))/sd(data$penr_akm,na.rm=T)
data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)

results_l <- foreach(parameter = listofh, .errorhandling = 'remove', .combine = rbind, .packages=c('data.table','fixest')) %do% {
  data <- setkey(data, penr, trend)
  data[,lhs := data[list(penr,trend+parameter)][["empl"]]]
  est<-feols(lhs ~ sho*benr_akm*penr_akm + trend | penr + quart^penr_akm_q + quart^benr_akm_q, data=subset(data,data$t1 == 1), cluster = ~ penr + trend, panel.id=c('penr','trend'), notes=FALSE,lean=TRUE,nthreads=num_tred)
  data <- subset(data,select=-c(lhs))
  return(c(parameter,est[["coefficients"]],est[["se"]]))
}  
results_l <- results_l %>% as.data.frame()
saveRDS(results_l, file = paste0(result_path,"figure_a12_regression_panels_b_c_d",".rds"))



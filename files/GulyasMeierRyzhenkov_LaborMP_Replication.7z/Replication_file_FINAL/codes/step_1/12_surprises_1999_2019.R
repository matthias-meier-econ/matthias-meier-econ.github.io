rm(list = ls(all.names = TRUE))

library(haven)
library(foreign)
library(dplyr)
library(lubridate)
library(ggplot2)
library(ggthemes)
library(corpcor)
library(psych)
library(matlib)

# load here surprises from  Altavilla et al. (2019)
cd <-
shocks<-paste0(cd,"shocks_2020.dta")

data_all <- shocks
data_reg <- shocks %>% filter(regular==1)
data_reg_pc <- shocks %>% filter(regular==1 & press_conference == 1)


data <- data_reg_pc


#U <- as.matrix(rbind(data$ois3/100,data$stoxx)) %>% t()
U <- as.matrix(rbind(data$ois6/100,data$stoxx)) %>% t()
#U <- as.matrix(rbind(data$ois12/100,data$stoxx)) %>% t()


var(U[,1])
var(U[,2])

S_u <- matrix(c(cov(U)), nrow=2, ncol=2)
S_u

P <- chol(S_u) %>% t
P

num_grid <- 10000
theta_grid <- seq(0, 2, by=((2-0)/(num_grid-1)))*pi

satisfy<-list()
notsatisfy<-list()
phi_yes<-vector()
phi_no<-vector()
B11<-vector()
B12<-vector()
B21<-vector()
B22<-vector()
a<-1
b<-1

foreach (i = 1:num_grid) %do% {
  Q <- matrix(c(cos(theta_grid[i]),-sin(theta_grid[i]),sin(theta_grid[i]),cos(theta_grid[i])), nrow=2, ncol=2)
  B_minus <- P %*% Q
  if (B_minus[1,1]>0 & B_minus[1,2]>0 & B_minus[2,1]<0 & B_minus[2,2]>0) {
    satisfy[[a]]<-B_minus
    phi_yes[a]<-theta_grid[i]
    B11[a]<-B_minus[1,1]
    B12[a]<-B_minus[1,2]
    B21[a]<-B_minus[2,1]
    B22[a]<-B_minus[2,2]
    a<-a+1
  } else {
    notsatisfy[[b]]<-B_minus
    phi_no[b]<-theta_grid[i]
    b<-b+1
  }
}

phi_star <- median(phi_yes)
phi_star
phi_star/pi

Q_star<-matrix(c(cos(phi_star),-sin(phi_star),sin(phi_star),cos(phi_star)), nrow=2, ncol=2)
Q_star

B_star <- P%*%Q_star
B_star
B_0<-inv(B_star)
B_0
omega<-B_0%*%t(U)
omega<-t(omega) %>% as_data_frame()



omega$ffr<-data$ois3/100
omega$ffr<-data$ois6/100
#omega$ffr<-data$ois12/100

omega$stock<-data$stoxx
omega$date<-data$date
omega$date<-as.Date(omega$date, origin = "1960-01-01")
names(omega)[names(omega) == "V1"] <- "mps"
names(omega)[names(omega) == "V2"] <- "cbs"
#omega$mps<-round(omega$mps,digits=5)

mean(omega$mps)
median(omega$mps)
sd(omega$mps)
min(omega$mps)
max(omega$mps)

describe(omega[,1:2])
cor(omega$mps,omega$cbs)>0.01

mplm<-lm(omega$ffr ~ omega$mps) 
cblm<-lm(omega$ffr ~ omega$cbs)
sd_mp<-as.double(mplm$coefficients[2])
sd_cb<-as.double(cblm$coefficients[2])

omega$mp<-(omega$mps * sd_mp) * 100
omega$cb<-(omega$cbs * sd_cb) * 100
omega$ir<-omega$ffr *100
omega$diff<-as.double((omega$mp+omega$cb)-omega$ir)
describe(omega$diff)
cor(omega$mp,omega$cb)>0.01
describe(omega[,6:7])


data$mps12<-omega$mp
data$cbs12<-omega$cb
 
data$mpp12 <- data$ois12*data$stoxx <=0
data$cbp12 <- data$ois12*data$stoxx >0

data$mpp12 <- data$mpp12 * data$ois12
data$cbp12 <- data$cbp12 * data$ois12

data_reg_pc <- data



shocks_all <- select(data_all,c("mps3","cbs3","mpp3","cbp3","mps6","cbs6","mpp6","cbp6","mps12","cbs12","mpp12","cbp12"))
shocks_all <- shocks_all %>% 
                            rename(
                              mps3_all = mps3,
                              cbs3_all = cbs3,
                              mpp3_all = mpp3,
                              cbp3_all = cbp3,
                              mps6_all = mps6,
                              cbs6_all = cbs6,
                              mpp6_all = mpp6,
                              cbp6_all = cbp6,
                              mps12_all = mps12,
                              cbs12_all = cbs12,
                              mpp12_all = mpp12,
                              cbp12_all = cbp12
                            )
shocks <- cbind(shocks,shocks_all)   


shocks_reg <- select(data_reg,c("date","ois3","ois6","ois12","mps3","cbs3","mpp3","cbp3","mps6","cbs6","mpp6","cbp6","mps12","cbs12","mpp12","cbp12"))
shocks_reg <- shocks_reg %>% 
  rename(
    ois3_reg = ois3,
    ois6_reg = ois6,
    ois12_reg = ois12,
    mps3_reg = mps3,
    cbs3_reg = cbs3,
    mpp3_reg = mpp3,
    cbp3_reg = cbp3,
    mps6_reg = mps6,
    cbs6_reg = cbs6,
    mpp6_reg = mpp6,
    cbp6_reg = cbp6,
    mps12_reg = mps12,
    cbs12_reg = cbs12,
    mpp12_reg = mpp12,
    cbp12_reg = cbp12
  )
shocks <- left_join(shocks, shocks_reg, by = c('date'), match='all')

shocks_reg_pc <- select(data_reg_pc,c("date","ois3","ois6","ois12","mps3","cbs3","mpp3","cbp3","mps6","cbs6","mpp6","cbp6","mps12","cbs12","mpp12","cbp12"))
shocks_reg_pc <- shocks_reg_pc %>% 
  rename(
    ois3_reg_pc = ois3,
    ois6_reg_pc = ois6,
    ois12_reg_pc = ois12,
    mps3_reg_pc = mps3,
    cbs3_reg_pc = cbs3,
    mpp3_reg_pc = mpp3,
    cbp3_reg_pc = cbp3,
    mps6_reg_pc = mps6,
    cbs6_reg_pc = cbs6,
    mpp6_reg_pc = mpp6,
    cbp6_reg_pc = cbp6,
    mps12_reg_pc = mps12,
    cbs12_reg_pc = cbs12,
    mpp12_reg_pc = mpp12,
    cbp12_reg_pc = cbp12
  )
shocks <- left_join(shocks, shocks_reg_pc, by = c('date'), match='all')


write.dta(shocks,paste0("shocks_2020_adj.dta")) 








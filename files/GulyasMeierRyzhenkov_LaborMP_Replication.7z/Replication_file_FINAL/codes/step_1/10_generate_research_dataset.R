rm(list = ls())                                                                                                                            
library(dplyr)                                                                                                                            
library(haven)                                                                                                                            
library(foreign)                                                                                                                          
library(statar)                                                                                                                           
library(data.table)                                                                                                                        
library(statar)                                                                                                                            
library(zoo)                                                                                                                              
library(lubridate)                                                                                                                       
library(lfe)                                                                                                                              
library(parallel)                                                                                                                         
library(doParallel)                                                                                                                       
library(fixest)                                                                                                                           
library(tictoc)                                                                                                                           
library(tidyverse)                                                                                                                         
library(tidyr)                                                                                                                            

data_path   <- "C:/Users/mykol/Dropbox/Research/Employment and Monetary Policy/_shareAndreasMatthias/mykola/"                            
code_path   <- "C:/Users/mykol/Dropbox/Research/Employment and Monetary Policy/_shareAndreasMatthias/mykola/codes/"                      
result_path <- "C:/Users/mykol/Dropbox/Research/Employment and Monetary Policy/_shareAndreasMatthias/mykola/outputs/"                    


data_E <- readRDS(paste0(data_path,"wpanel.rds")) %>% as.data.frame()   
data_U <- readRDS(paste0(data_path,"wpanel_UE.rds"))   %>% as.data.frame()   

data_p1 <- readRDS(paste0(data_path,"MPShocks_penr_fe_rolling_AKM.rds")) %>% as.data.frame()
data_b1 <- readRDS(paste0(data_path,"MPShocks_benr_fe_rolling_AKM.rds")) %>% as.data.frame()
data_p2 <- readRDS(paste0(data_path,"MPShocks_penr_fe_rolling_AKM_tenure.rds")) %>% as.data.frame()
data_b2 <- readRDS(paste0(data_path,"MPShocks_benr_fe_rolling_AKM_tenure.rds")) %>% as.data.frame()
data_p3 <- readRDS(paste0(data_path,"MPShocks_penr_fe_lam_rolling_AKM.rds")) %>% as.data.frame()
data_b3 <- readRDS(paste0(data_path,"MPShocks_benr_fe_lam_rolling_AKM.rds")) %>% as.data.frame()
data_p4 <- readRDS(paste0(data_path,"MPShocks_penr_empshare.rds")) %>% as.data.frame()
data_b4 <- readRDS(paste0(data_path,"MPShocks_benr_poachR.rds")) %>% as.data.frame()

data_E <- select(data_E,-c(benr_age,austrian))
data_E$wage_lag <- data_E$yearinc_L1 / data_E$year_days_L1  
data_E <- select(data_E,-c(yearinc_L1,year_days_L1))
data_U <- select(data_U,-c(anfdat,enddat,jahr))
data_E$empl <- 1
data_U$empl <- 0

data_U$benr <- NA
data_U$firmTenure <- NA
data_U$nace1 <- NA
data_U$nuts <- NA
data_U$firm_age <- NA
data_U$benr_fe <- NA
data_U$penr_fe <- NA
data_U$benr_fe_tenure <- NA
data_U$penr_fe_tenure <- NA
data_U$benr_fe_lam <- NA
data_U$penr_fe_lam <- NA
data_U$bluecollar <- NA
data_U$dailyWage <- NA
data_U$Qempdays <- NA
data_U$maxdays <- NA
data_U$wage_lag <- NA

data <- rbind(data_E,data_U)
rm(data_E,data_U)
data$jahr <- year(data$day)
data$day <- as.quarterly(data$day)  
data$trend <- as.numeric(data$day)
data$trend <- data$trend - min(data$trend) + 1
data$quart <- substr(quarters(as.Date(data$day)), 2, 2)  
data <- select(data,-c(day))

tmpd <- select(data,c(trend,jahr))
tmpd <- tmpd %>% distinct()
data <- select(data,-c(jahr))
data$nofill <- 1
data <- tibble(data)                                                                                                                     
data <- data %>% group_by(trend,benr) %>% mutate( firm_size = sum(empl) )                                                               
data$firm_size <- ifelse(is.na(data$benr)==T,NA,data$firm_size )
data <- data %>% ungroup()
data <- data %>% group_by(trend,nuts,nace1) %>% mutate( market_size = sum(empl) )                                                             
data <- data %>% ungroup()                                                                                                               
data$mkt_share <- data$firm_size / data$market_size  
data <- select(data,-c(market_size,nuts))

tmpmm <- data %>% group_by(penr) %>% summarise(min_t = min(trend,na.rm = T), max_t = max(trend,na.rm = T))

panel <- expand.grid(trend = min(data$trend):max(data$trend),penr = unique(data$penr) )
panel <- left_join(panel,tmpmm)
panel <- panel[ panel$trend>=panel$min_t & panel$trend<=panel$max_t,] 
panel <- select(panel,-c(min_t,max_t))
panel <- left_join(panel,data)
rm(data)
panel <- panel[with(panel, order(penr, trend)), ] 
panel <- panel %>% group_by(penr) %>% mutate(gebj = mean(gebj,na.rm=T)  )
panel <- left_join(panel,tmpd)
rm(tmpd)
panel$worker_age <-  panel$jahr - panel$gebj
panel <- select(panel,-c(gebj))

panel <- panel %>% group_by(trend) %>% mutate(quart = min(quart, na.rm=T)  )
panel <- panel %>% ungroup()
panel$empl <- ifelse(is.na(panel$empl)==T,0,panel$empl )

panel <- left_join(panel,data_p1)
rm(data_p1)
panel <- left_join(panel,data_p2)
rm(data_p2)
panel <- left_join(panel,data_p3)
rm(data_p3)
panel <- left_join(panel,data_p4)
rm(data_p4)

panel <- panel %>% as.data.table()
panel <- panel[with(panel, order(penr, trend)), ]
panel <- setkey(panel, penr, trend)

panel[ , benr_l := panel[list(penr,trend-1)][["benr"]]]
panel$benr_l <- ifelse(panel$quart==1, panel$benr, panel$benr_l)
data_b1 <- rename(data_b1,benr_l = benr)  
data_b2 <- rename(data_b2,benr_l = benr)  
data_b3 <- rename(data_b3,benr_l = benr)  
data_b4 <- rename(data_b4,benr_l = benr)  

panel <- left_join(panel,data_b1)
rm(data_b1)
panel <- left_join(panel,data_b2)
rm(data_b2)
panel <- left_join(panel,data_b3)
rm(data_b3)
panel <- left_join(panel,data_b4)
rm(data_b4)
panel <- select(panel,-c(benr_l))
panel <- select(panel,-c(jahr))

panel <- panel %>% group_by(penr) %>% mutate(female = mean(female,na.rm=T) )

saveRDS(panel, file = paste0(data_path,"dataMP_with_fill_revision.rds"))

panel <- panel %>% filter(nofill==1)
panel <- select(panel,-c(nofill))
saveRDS(panel, file = paste0(data_path,"dataMP_no_fill_revision.rds"))







#Convert dataset into R format
rm(list=ls())
library(haven)
library(dplyr)

#set path
savepath <- "E:/bwSyncAndShare/AMDB/STATA/genData/MPShocks/"




data <- read_dta( paste0(savepath,"amdb_MPShocks.dta") )

#convert transitions to integers


data <- data %>% mutate_at(
  c("sepa" , "sepa_recall" , "EN" , "EU" , "EE" , "sepa_nonempdur" ,
    "hire" , "hire_recall" , "hire_E" , "hire_U" , "hire_N" , "hire_nonempdur" , 
    "nace" , "nace1" , "sector" , "firm_age" ,
    "austrian" , "bluecollar" , "firmTenure" , "female" ,
    "btag" , "gebj" , "jahr" , "year_days") , 
  as.integer)


data <- data %>% arrange(penr,anfdat)

saveRDS(data , paste0(savepath,"amdb_MPShocks.rds") )




###########################################
# convert person effects

penrEffect <- read_dta( paste0(savepath,"MPShocks_penr_fe_rolling_AKM.dta") )

penrEffect <- penrEffect %>% mutate_at(
  c("jahr") , 
  as.integer)

saveRDS(penrEffect , paste0(savepath,"MPShocks_penr_fe_rolling_AKM.rds") )




###########################################
# convert benr effects

benrEffect <- read_dta( paste0(savepath,"MPShocks_benr_fe_rolling_AKM.dta") )

benrEffect <- benrEffect %>% mutate_at(
  c("jahr") , 
  as.integer)

saveRDS(benrEffect , paste0(savepath,"MPShocks_benr_fe_rolling_AKM.rds") )


################################################################################
# Everything with AKM with tenure effects
################################################################################




###########################################
# convert person effects

penrEffect <- read_dta( paste0(savepath,"MPShocks_penr_fe_rolling_AKM_tenure.dta") )

penrEffect <- penrEffect %>% mutate_at(
  c("jahr") , 
  as.integer)

saveRDS(penrEffect , paste0(savepath,"MPShocks_penr_fe_rolling_AKM_tenure.rds") )



###########################################
# convert benr effects

benrEffect <- read_dta( paste0(savepath,"MPShocks_benr_fe_rolling_AKM_tenure.dta") )

benrEffect <- benrEffect %>% mutate_at(
  c("jahr") , 
  as.integer)

saveRDS(benrEffect , paste0(savepath,"MPShocks_benr_fe_rolling_AKM_tenure.rds") )


################################################################################
# Everything with AKM with Lamadon clustering effects
################################################################################



###########################################
# convert person effects

penrEffect <- read_dta( paste0(savepath,"MPShocks_penr_fe_lam_rolling_AKM.dta") )

penrEffect <- penrEffect %>% mutate_at(
  c("jahr") , 
  as.integer)

saveRDS(penrEffect , paste0(savepath,"MPShocks_penr_fe_lam_rolling_AKM.rds") )




###########################################
# convert benr effects

benrEffect <- read_dta( paste0(savepath,"MPShocks_benr_fe_lam_rolling_AKM.dta") )

benrEffect <- benrEffect %>% mutate_at(
  c("jahr") , 
  as.integer)

saveRDS(benrEffect , paste0(savepath,"MPShocks_benr_fe_lam_rolling_AKM.rds") )


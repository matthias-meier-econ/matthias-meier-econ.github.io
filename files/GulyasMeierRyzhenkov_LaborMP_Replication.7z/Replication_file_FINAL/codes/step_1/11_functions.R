##########################################################################################################################################################
###                                                                                                                                                    ###
###     ****** **  ** **  **  ****  ****** **  ****  **  **  ****                                                                                      ###
###     **     **  ** *** ** **   *   **   ** **  ** *** ** *                                                                                          ###
###     ****   **  ** ** *** **       **   ** **  ** ** ***  ****                                                                                      ###
###     **     **  ** **  ** **   *   **   ** **  ** **  **      *                                                                                     ###
###     **      ****  **  **  ****    **   **  ****  **  **  ****                                                                                      ###
###                                                                                                                                                    ###
##########################################################################################################################################################
##########################################################################################################################################################
###                    GENERATE DATA                                                                                                                   ###
##########################################################################################################################################################
generate_data <- function(akm_window,akm_version, shon, age_restriction = TRUE, var_add="none", fill=FALSE, User, data_path){               
  ### shocks                                                                                                                               
  shocks <- read_dta(paste0(data_path,"shocks_quarterly_1999_2019.dta")) %>% as.data.frame()                                                                   
  shocks$date<-as.Date(with(shocks,paste(year,month,day,sep="-")),"%Y-%m-%d")                                                              
  shocks$date <- as.quarterly(shocks$date)                                                                                                 
  shocks <- dplyr::select(shocks,-c(year,month,day,qdate))                                                                                 
  sho_na <- names(shocks)[1:6]                                                                                                             
  s <- shon                                                                                                                                
  sho <- dplyr::select(shocks, c("date",all_of(sho_na[s])))                                                                                       
  names(sho) <- c("date","sho")                                                                                                            
  rm(shocks)                                                                                                                               
  sho$trend <- as.numeric(sho$date)                                                                                                        
  sho$trend <- sho$trend - min(sho$trend) + 1                                                                                              
  sho <- dplyr::select(sho, -(date))                                                                                                              
  ### employment data                                                                                                                      
  if(fill==FALSE){
    data <- readRDS(paste0(data_path,"dataMP_no_fill_revision.rds"))                                                              
  } else{data <- readRDS(paste0(data_path,"dataMP_with_fill_revision.rds"))}  
  data <- subset(data,data$trend<85)
  if (age_restriction == TRUE){
    data <- data[ data$worker_age>=26 & data$worker_age<=60,]
  }
  if(akm_version=="standard"){                                                                                                             
    if(akm_window=="roll"){                                                                                                                
      data <- dplyr::select(data,-c(benr_fe,penr_fe,benr_fe_tenure,penr_fe_tenure,penr_fe_lam,benr_fe_lam,penr_fe_p_tenure_rolling,penr_fe_lam_p_rolling,penr_empshare_p_rolling,benr_fe_p_tenure_rolling,benr_fe_lam_p_rolling,benr_poachR_p_rolling))             
      data <- rename(data, benr_akm = benr_fe_p_rolling, penr_akm = penr_fe_p_rolling)                                                                 
    } else{                                                                                                                                            
      data <- dplyr::select(data,-c(benr_fe_p_rolling,penr_fe_p_rolling,benr_fe_tenure,penr_fe_tenure,penr_fe_lam,benr_fe_lam,penr_fe_p_tenure_rolling,penr_fe_lam_p_rolling,penr_empshare_p_rolling,benr_fe_p_tenure_rolling,benr_fe_lam_p_rolling,benr_poachR_p_rolling))                                                                              
      data <- rename(data, benr_akm = benr_fe, penr_akm = penr_fe)                                                                         
    }  
  }else if(akm_version=="tenure"){
    if(akm_window=="roll"){                                                                                                                
      data <- dplyr::select(data,-c(benr_fe,penr_fe,penr_fe_p_rolling,benr_fe_p_rolling,benr_fe_tenure,penr_fe_tenure,penr_fe_lam,benr_fe_lam,benr_fe_lam_p_rolling,penr_fe_lam_p_rolling,penr_empshare_p_rolling,benr_poachR_p_rolling))             
      data <- rename(data, benr_akm = benr_fe_p_tenure_rolling, penr_akm = penr_fe_p_tenure_rolling)                                                                 
    } else{                                                                                                                                            
      data <- dplyr::select(data,-c(benr_fe,penr_fe,penr_fe_p_rolling,benr_fe_p_rolling,benr_fe_p_tenure_rolling,penr_fe_p_tenure_rolling,penr_fe_lam,benr_fe_lam,benr_fe_lam_p_rolling,penr_fe_lam_p_rolling,penr_empshare_p_rolling,benr_poachR_p_rolling))
      data <- rename(data, benr_akm = benr_fe_tenure, penr_akm = penr_fe_tenure)                                                                         
    }  
  }else if(akm_version=="lamadon"){
    if(akm_window=="roll"){                                                                                                                
      data <- dplyr::select(data,-c(benr_fe,penr_fe,penr_fe_p_rolling,benr_fe_p_rolling,benr_fe_tenure,penr_fe_tenure,benr_fe_p_tenure_rolling,penr_fe_p_tenure_rolling,penr_fe_lam,benr_fe_lam,penr_empshare_p_rolling,benr_poachR_p_rolling))             
      data <- rename(data, benr_akm = benr_fe_lam_p_rolling, penr_akm = penr_fe_lam_p_rolling)                                                                 
    } else{                                                                                                                                            
      data <- dplyr::select(data,-c(benr_fe,penr_fe,penr_fe_p_rolling,benr_fe_p_rolling,penr_fe_tenure,benr_fe_tenure,benr_fe_p_tenure_rolling,penr_fe_p_tenure_rolling,benr_fe_lam_p_rolling,penr_fe_lam_p_rolling,penr_empshare_p_rolling,benr_poachR_p_rolling))
      data <- rename(data, benr_akm = benr_fe_lam, penr_akm = penr_fe_lam)                                                                         
    }  
  }else if(akm_version=="crane"){
    if(akm_window=="roll"){                                                                                                                
      data <- dplyr::select(data,-c(benr_fe,penr_fe,penr_fe_p_rolling,benr_fe_p_rolling,penr_fe_tenure,benr_fe_tenure,benr_fe_p_tenure_rolling,penr_fe_p_tenure_rolling,penr_fe_lam,benr_fe_lam,benr_fe_lam_p_rolling,penr_fe_lam_p_rolling))             
      data <- rename(data, benr_akm = benr_poachR_p_rolling, penr_akm = penr_empshare_p_rolling)                                                                 
    } else{                                                                                                                                            
      print("wrong")                                                                          
    }  
  }else{ print("wrong")  } 
  
  if(var_add == "none"){ data <- dplyr::select(data, c("penr","benr","penr_akm","benr_akm","trend","empl","quart"))                               
  } else if(var_add == "all"){ data <- data
  } else if(var_add == "wage_all"){ data <- dplyr::select(data, c("penr","benr","penr_akm","benr_akm","trend","empl","quart","dailyWage","Qempdays","maxdays"))
  } else{data <- dplyr::select(data, c("penr","benr","penr_akm","benr_akm","trend","empl","quart",all_of(var_add))) }                             
  data <- arrange(data, penr, trend)                                                                                                       
  data %>% group_by(penr) %>% is.panel(trend)                                                                                              
  # merge data with shocks                                                                                                                 
  data <- left_join(data,sho)                                                                                                              
  data$sho<- data$sho/sd(data$sho, na.rm = T)                                                                                              
  data$quart <- as.factor(data$quart)                                                                                                      
  data <- data %>% as.data.table()                                                                                                         
  data <- data[with(data, order(penr, trend)), ]                                                                                           
  setkey(data, penr, trend)                                                                                                                
  rm(sho)                                                                                                                                  
  table(data$empl)                                                                                                                         
  return(data)                                                                                                                             
}         
##########################################################################################################################################################
###                    QUINTILES                                                                                                                       ###
##########################################################################################################################################################
generate_quintiles <- function(data,var,lag){                                                                                              
  data <- data %>% as.data.table()                                                                                                         
  data <- data[with(data, order(penr, trend)), ]                                                                                           
  data <- setkey(data, penr, trend)                                                                                                                
  if(lag==1){                                                                                                                              
    data[ , var_l := data[list(penr,trend-1)][[var]]]                                                                                      
  } else{                                                                                                                                  
    data$var_l <- data[[var]]                                                                                                              
  }                                                                                                                                        
  qntl <- quantile(data$var_l, probs = seq(0, 1, 0.2), na.rm = TRUE)                                                                       
  data$quint_v <- NA                                                                                                                       
  data$quint_v <- ifelse( data$var_l <= qntl[2]                         , 1 ,data$quint_v )                                                
  data$quint_v <- ifelse( data$var_l >  qntl[2] & data$var_l <= qntl[3] , 2 ,data$quint_v )                                                
  data$quint_v <- ifelse( data$var_l >  qntl[3] & data$var_l <= qntl[4] , 3 ,data$quint_v )                                                
  data$quint_v <- ifelse( data$var_l >  qntl[4] & data$var_l <= qntl[5] , 4 ,data$quint_v )                                                
  data$quint_v <- ifelse( data$var_l >  qntl[5]                         , 5 ,data$quint_v )                                                
  data <- dplyr::select(data,-c(var_l))                                                                                                           
  setkey(data, penr, trend)                                                                                                                
  data$quint_v <- as.factor(data$quint_v)                                                                                                  
  setnames(data, "quint_v", paste0(var,"_q") )                                                                                             
  return(data)                                                                                                                             
}                                                                                                                                          
##########################################################################################################################################################
###                    MEDIAN                                                                                                                          ###
##########################################################################################################################################################
generate_median <- function(data,var,lag){                                                                                                 
  data <- data %>% as.data.table()                                                                                                         
  data <- data[with(data, order(penr, trend)), ]                                                                                           
  data <- setkey(data, penr, trend)                                                                                                                
  if(lag==1){                                                                                                                              
    data[ , var_l := data[list(penr,trend-1)][[var]]]                                                                                      
  } else{                                                                                                                                  
    data$var_l <- data[[var]]                                                                                                              
  }                                                                                                                                        
  qntl <- quantile(data$var_l, probs = seq(0, 1, 0.5), na.rm = TRUE)                                                                       
  data$quint_m <- NA                                                                                                                       
  data$quint_m <- ifelse( data$var_l <= qntl[2] , 1 ,data$quint_m )                                                                        
  data$quint_m <- ifelse( data$var_l >  qntl[2] , 2 ,data$quint_m )                                                                        
  data <- dplyr::select(data,-c(var_l))                                                                                                           
  setkey(data, penr, trend)                                                                                                                
  data$quint_m <- as.factor(data$quint_m)                                                                                                  
  setnames(data, "quint_m", paste0(var,"_m") )                                                                                             
  return(data)                                                                                                                             
}     
##########################################################################################################################################################
###                    END                                                                                                                             ###
##########################################################################################################################################################
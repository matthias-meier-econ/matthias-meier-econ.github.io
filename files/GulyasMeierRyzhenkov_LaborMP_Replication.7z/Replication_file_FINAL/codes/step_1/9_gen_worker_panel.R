#Generate quarterly worker panel


rm(list = ls(all.names = TRUE))

library(foreign)
library(tibble)
library(lubridate)
library(parallel)
library(haven)
library(tidyr)
library(dplyr)
library(data.table)
library(dtplyr)


options(scipen=999)


############################################################################

savepath <- "E:/bwSyncAndShare/AMDB/STATA/genData/MPShocks/"

data <- readRDS( paste0(savepath,"amdb_MPShocks.rds") )




#deselect worker categories
data <- data %>% select(anfdat , enddat , penr, benr , gebj , benr_age , female , firmTenure , nace1 , nuts , austrian , 
                        firm_age , benr_fe , penr_fe , benr_fe_tenure , penr_fe_tenure , penr_fe_lam , benr_fe_lam , yearinc_L1 ,  year_days_L1 , dailyWage ,
                        bluecollar)




############################################################################
# compute quarterly employment days


data <- lazy_dt(data)


Qanf <- seq.Date(as.Date('1999-01-01') , as.Date('2020-12-31') , by="1 quarter")
Qend <- seq.Date(as.Date('1999-01-01') , as.Date('2020-12-31') , by="1 quarter") + months(3) - days(1)



quarterly_empdays <- function(ind , Qanf , Qend) {
  print(Qend[ind])
  data %>% 
    filter( (enddat >= Qanf[ind] & enddat <= Qend[ind]) | 
              anfdat >= Qanf[ind] & anfdat <= Qend[ind] |
              anfdat <= Qanf[ind] & enddat >= Qend[ind])  %>% 
    mutate(anfdatnew = if_else( Qanf[ind] > anfdat , Qanf[ind] , anfdat) ,
           enddatnew = if_else( Qend[ind] < enddat , Qend[ind] , enddat) ) %>%
    group_by(penr) %>%
    mutate(Qempdays = sum(enddatnew - anfdatnew + 1)) %>%
    select(penr, Qempdays)  %>%
    slice(1) %>%
    as.data.frame() %>%
    add_column(day = Qend[ind],
               maxdays = Qend[ind] - Qanf[ind] + 1)
}



worker_panel_Qempdays <- vector()
tic()
worker_panel_Qempdays <- do.call("bind_rows",lapply(1:length(Qanf) , FUN= function(i){quarterly_empdays(i,Qanf,Qend)} ))
toc()

data <- as.data.frame(data)

saveRDS(worker_panel_Qempdays , paste0(savepath,"worker_panel_Qempdays.rds") )

#######################################################################
# compute rest of quarterly data

date_q1 <- seq.Date(as.Date('1999-01-01') , as.Date('2005-12-31') , by="1 quarter") + months(3) - days(1)
date_q2 <- seq.Date(as.Date('2006-01-01') , as.Date('2010-12-31') , by="1 quarter") + months(3) - days(1)
date_q3 <- seq.Date(as.Date('2011-01-01') , as.Date('2015-12-31') , by="1 quarter") + months(3) - days(1)
date_q4 <- seq.Date(as.Date('2016-01-01') , as.Date('2020-12-31') , by="1 quarter") + months(3) - days(1)



quarterly_data <- function(day) {
  print(day)
  data %>% 
    filter(anfdat <= day & enddat>=day) %>% 
    select(penr, benr , gebj , benr_age , female , firmTenure , nace1 , nuts , austrian , 
           firm_age , benr_fe , penr_fe , benr_fe_tenure , penr_fe_tenure, penr_fe_lam , benr_fe_lam , yearinc_L1 ,  year_days_L1 , bluecollar , dailyWage)  %>%
    add_column(day = day)
}

worker_panel_quarter1 <- vector()
worker_panel_quarter1 <- do.call("bind_rows",lapply(date_q1 , FUN=quarterly_data))

worker_panel_quarter2 <- vector()
worker_panel_quarter2 <- do.call("bind_rows",lapply(date_q2 , FUN=quarterly_data))

worker_panel_quarter3 <- vector()
worker_panel_quarter3 <- do.call("bind_rows",lapply(date_q3 , FUN=quarterly_data))


worker_panel_quarter4 <- vector()
worker_panel_quarter4 <- do.call("bind_rows",lapply(date_q4 , FUN=quarterly_data))



rm(data)

wpanel <- rbind(worker_panel_quarter1 , worker_panel_quarter2 , worker_panel_quarter3)

rm(worker_panel_quarter1)
rm(worker_panel_quarter2)
rm(worker_panel_quarter3)

wpanel <- rbind(wpanel , worker_panel_quarter4)

rm(worker_panel_quarter4)

wpanel <- wpanel %>% arrange(penr , day)



#merge worker panel and empdays

wpanel <- left_join(wpanel , worker_panel_Qempdays , by = c("penr" , "day"))

saveRDS(wpanel , paste0(savepath,"wpanel.rds") )




#  _   _ _____  __        __         _               ____                  _ 
# | | | | ____| \ \      / /__  _ __| | _____ _ __  |  _ \ __ _ _ __   ___| |
# | | | |  _|    \ \ /\ / / _ \| '__| |/ / _ \ '__| | |_) / _` | '_ \ / _ \ |
# | |_| | |___    \ V  V / (_) | |  |   <  __/ |    |  __/ (_| | | | |  __/ |
#  \___/|_____|    \_/\_/ \___/|_|  |_|\_\___|_|    |_|   \__,_|_| |_|\___|_|
#                                                                             

#generate worker panel for unemployed workers

rm(list = ls())

data <- read_dta(file= paste0(savepath,"amdb_MPShocks_UEspells.dta") )



date_q1 <- seq.Date(as.Date('1999-01-01') , as.Date('2020-12-31') , by="1 quarter") + months(3) - days(1)

quarterly_data <- function(day) {
  print(day)
  data %>% 
    filter(anfdat <= day & enddat>=day) %>% 
    add_column(day = day)
}

worker_UE_panel <- vector()
worker_UE_panel <- do.call("bind_rows",lapply(date_q1 , FUN=quarterly_data))


worker_UE_panel <- worker_UE_panel %>% arrange(penr , anfdat)


saveRDS(worker_UE_panel , paste0(savepath,"wpanel_UE.rds") )



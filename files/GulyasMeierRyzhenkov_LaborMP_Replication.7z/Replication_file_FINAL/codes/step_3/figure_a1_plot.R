rm(list = ls())                                                                            
library(dplyr)                                                                             
library(haven)                                                                             
library(foreign)                                                                           
library(statar)                                                                            
library(data.table)                                                                        
library(statar)                                                                            
library(zoo)                                                                               
library(lubridate)                                                                         
library(lfe)                                                                               
library(parallel)                                                                          
library(doParallel)                                                                        
library(fixest)                                                                            
library(tictoc)                                                                            
library(ggplot2) 
library(lmtest)
library(sandwich)

cd <-
data_path   <- cd                
code_path   <- paste0(cd,"codes/")                 
result_path <- paste0(cd,"outputs/")
figure_path   <- paste0(cd,"figures/")

sho_na <- c("ois3_mq","mpp3_mq","mps3_mq","ois6_mq","mpp6_mq","mps6_mq")                                                                   
s<-6

shocks <- read_dta(paste0(data_path,"shocks_quarterly_1999_2019.dta"))                                                                             
shocks$sho<- shocks$mps6_mq/sd(shocks$mps6_mq, na.rm = T)                                                                                              
shocks$dt <- ISOdate(shocks$year, shocks$month, shocks$day)
shocks <- shocks %>% mutate(year2 = lubridate::year(dt))

library(zoo)
shocks$yq <- as.yearqtr(shocks$dt, format = "%Y-%m-%d")
shocks$yq

plt <- ggplot(shocks, aes(x=yq, y=mps6_mq)) + geom_bar(stat = "identity", width=0.2) +
  geom_bar(stat="identity", fill="blue",colour="darkblue", size=0.1) + 
  xlab("Period") + ylab("Surprise (in b.p.)") + 
  theme_minimal() + 
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  scale_y_continuous(limits=c(-25,15),breaks=seq(-25,15,5), expand = c(0.1, 0.1), labels = scales::comma) +
  scale_x_yearqtr(format = "%Y", breaks = seq(from = min(shocks$yq), to = max(shocks$yq), by = 4)) + 
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_a1_plot.pdf"),path = figure_path,width = 8,height = 6)


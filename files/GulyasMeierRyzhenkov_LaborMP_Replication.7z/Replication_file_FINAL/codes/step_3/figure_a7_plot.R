rm(list = ls())

library(ggplot2)
library(dplyr)

cd <-
figure_path   <- paste0(cd,"figures/")
data_path   <- paste0(cd,"outputs/") 

## EMPLOYMENT


out_nm <- "figure_a7_panel_a_regression_3"
data_h <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_a_vcov_3"
vcov_h <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a7_panel_a_regression_1"
data_f <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_a_vcov_1"
vcov_f <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a7_panel_a_regression_2"
data_w <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_a_vcov_2"
vcov_w <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_1_regression"
data_a <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

b_a <- data_a[6,2] * 100
sa_a <- data_a[6,4] * 100

w_p_l <- 0
w_p_h <- 1
w_b_l <- 0
w_b_h <- 1

b_s <- data_h[1,4]
b_b <- data_h[1,7]
b_p <- data_h[1,8]
b_i <- data_h[1,9]

wei_wl_fl = c(1,w_p_l,w_b_l,(w_p_l*w_b_l)) %>% as.matrix()%>% t()
wei_wl_fh = c(1,w_p_l,w_b_h,(w_p_l*w_b_h)) %>% as.matrix()%>% t()
wei_wh_fl = c(1,w_p_h,w_b_l,(w_p_h*w_b_l)) %>% as.matrix()%>% t()
wei_wh_fh = c(1,w_p_h,w_b_h,(w_p_h*w_b_h)) %>% as.matrix()%>% t()

b = c(b_s,b_p,b_b,b_i) %>% as.matrix() %>% t()

se <- rbind(c(vcov_h[3,3],vcov_h[3,7],vcov_h[3,6],vcov_h[3,8]),c(vcov_h[7,3],vcov_h[7,7],vcov_h[7,6],vcov_h[7,8]),c(vcov_h[6,3],vcov_h[6,7],vcov_h[6,6],vcov_h[6,8]),c(vcov_h[8,3],vcov_h[8,7],vcov_h[8,6],vcov_h[8,8])) %>% as.matrix()

b_in = 100 * c( wei_wl_fl%*%t(b),wei_wl_fh%*%t(b),wei_wh_fl%*%t(b),wei_wh_fh%*%t(b)) %>% as.data.frame()

wei_wl_fl2 = t(wei_wl_fl) %*% wei_wl_fl
wei_wl_fh2 = t(wei_wl_fh) %*% wei_wl_fh
wei_wh_fl2 = t(wei_wh_fl) %*% wei_wh_fl
wei_wh_fh2 = t(wei_wh_fh) %*% wei_wh_fh

s_in = c( 100*sqrt(c(wei_wl_fl2)%*%c(se)), 100*sqrt(c(wei_wl_fh2)%*%c(se)), 100*sqrt(c(wei_wh_fl2)%*%c(se)), 100*sqrt(c(wei_wh_fh2)%*%c(se)) )%>% as.data.frame()


b_ws <- data_w[1,3]
b_wp <- data_w[1,5]
wei_wl = c(1,w_p_l) %>% as.matrix()%>% t()
wei_wh = c(1,w_p_h) %>% as.matrix()%>% t()
b_w = c(b_ws,b_wp) %>% as.matrix() %>% t()
se_w <- rbind(c(vcov_w[2,2],vcov_w[2,4]),c(vcov_w[4,2],vcov_w[4,4])) %>% as.matrix()
b_wout = 100 * c( wei_wl%*%t(b_w),wei_wh%*%t(b_w)) %>% as.data.frame()
wei_wl2 = t(wei_wl) %*% wei_wl
wei_wh2 = t(wei_wh) %*% wei_wh
s_wout = c( 100*sqrt(c(wei_wl2)%*%c(se_w)), 100*sqrt(c(wei_wh2)%*%c(se_w)) )%>% as.data.frame()

b_fs <- data_f[1,3]
b_fb <- data_f[1,5]
wei_fl = c(1,w_p_l) %>% as.matrix()%>% t()
wei_fh = c(1,w_p_h) %>% as.matrix()%>% t()
b_f = c(b_fs,b_fb) %>% as.matrix() %>% t()
se_f <- rbind(c(vcov_f[2,2],vcov_f[2,4]),c(vcov_f[4,2],vcov_f[4,4])) %>% as.matrix()
b_fout = 100 * c( wei_fl%*%t(b_f),wei_fh%*%t(b_f)) %>% as.data.frame()
wei_fl2 = t(wei_fl) %*% wei_fl
wei_fh2 = t(wei_fh) %*% wei_fh
s_fout = c( 100*sqrt(c(wei_fl2)%*%c(se_f)), 100*sqrt(c(wei_fh2)%*%c(se_f)) )%>% as.data.frame()

b_s <- b_a
s_s <- sa_a

plt <- data.frame(matrix(ncol = 4, nrow = 9))
colnames(plt) <- c("firm_type", "worker_type", "b","se")
plt[1,] <- list("Low-paying"  ,"Low-paid"  , b_in[1,] , paste0("(",format(round(s_in[1,],3), nsmall = 3),")") )
plt[2,] <- list("High-paying" ,"Low-paid"  , b_in[2,] , paste0("(",format(round(s_in[2,],3), nsmall = 3),")") )
plt[3,] <- list("Low-paying"  ,"High-paid" , b_in[3,] , paste0("(",format(round(s_in[3,],3), nsmall = 3),")") )
plt[4,] <- list("High-paying" ,"High-paid" , b_in[4,] , paste0("(",format(round(s_in[4,],3), nsmall = 3),")") )
plt[5,] <- list("All" ,"Low-paid" , b_wout[1,] , paste0("(",format(round(s_wout[1,],3), nsmall = 3),")") )
plt[6,] <- list("All" ,"High-paid" , b_wout[2,] , paste0("(",format(round(s_wout[2,],3), nsmall = 3),")") )
plt[7,] <- list("All" ,"All" , b_s , paste0("(",format(round(s_s,3), nsmall = 3),")")  )
plt[8,] <- list("Low-paying"  ,"All"  , b_fout[1,] , paste0("(",format(round(s_fout[1,],3), nsmall = 3),")") )
plt[9,] <- list("High-paying"  ,"All"  , b_fout[2,] , paste0("(",format(round(s_fout[2,],3), nsmall = 3),")") )
plt$firm_type <- factor(plt$firm_type, levels = unique(as.character(plt[[1]])))
plt$worker_type <- factor(plt$worker_type, levels = unique(as.character(plt[[2]])))

htm <- ggplot(plt, aes(firm_type,worker_type, fill= b)) + 
  geom_tile(color = "black") +
  theme_minimal() +
  xlab("Firm type") +
  ylab("Worker type") +
  coord_fixed() + 
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_text(aes(label = format(round(b,3), nsmall = 3)), color = "white", size = 8, position = position_nudge(y = 0.1)) +
  geom_text(aes(label = se), color = "white", size = 6, position = position_nudge(y = -0.2)) +
  theme(legend.position = "none") +
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5, hjust = 0.5), legend.spacing.y = unit(0.7, 'cm')) +
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),plot.title = element_text(size = 19),panel.grid.minor = element_blank(),legend.title = element_text(size = 16),legend.text=element_text(size=16))
plot(htm)
ggsave(paste0("figure_a7_plot_panel_a.pdf"),path = figure_path,width = 8,height = 6)


## SWITCH

out_nm <- "figure_a7_panel_b_regression_1"
data_f <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_b_vcov_1"
vcov_f <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a7_panel_b_regression_2"
data_w <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_b_vcov_2"
vcov_w <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_3_regression"
data_a <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

b_a <- data_a[6,2] * 100
sa_a <- data_a[6,4] * 100

w_p_l <- 0
w_p_h <- 1
w_b_l <- 0
w_b_h <- 1

b_in = 100 * c( data_h[1,6],data_h[1,7],data_h[1,8],data_h[1,9]) %>% as.data.frame()
s_in = 100*c( data_h[1,14],data_h[1,15],data_h[1,16],data_h[1,17] )%>% as.data.frame()

b_ws <- data_w[1,3]
b_wp <- data_w[1,5]
wei_wl = c(1,w_p_l) %>% as.matrix()%>% t()
wei_wh = c(1,w_p_h) %>% as.matrix()%>% t()
b_w = c(b_ws,b_wp) %>% as.matrix() %>% t()
se_w <- rbind(c(vcov_w[2,2],vcov_w[2,4]),c(vcov_w[4,2],vcov_w[4,4])) %>% as.matrix()
b_wout = 100 * c( wei_wl%*%t(b_w),wei_wh%*%t(b_w)) %>% as.data.frame()
wei_wl2 = t(wei_wl) %*% wei_wl
wei_wh2 = t(wei_wh) %*% wei_wh
s_wout = c( 100*sqrt(c(wei_wl2)%*%c(se_w)), 100*sqrt(c(wei_wh2)%*%c(se_w)) )%>% as.data.frame()

b_fs <- data_f[1,3]
b_fb <- data_f[1,5]
wei_fl = c(1,w_p_l) %>% as.matrix()%>% t()
wei_fh = c(1,w_p_h) %>% as.matrix()%>% t()
b_f = c(b_fs,b_fb) %>% as.matrix() %>% t()
se_f <- rbind(c(vcov_f[2,2],vcov_f[2,4]),c(vcov_f[4,2],vcov_f[4,4])) %>% as.matrix()
b_fout = 100 * c( wei_fl%*%t(b_f),wei_fh%*%t(b_f)) %>% as.data.frame()
wei_fl2 = t(wei_fl) %*% wei_fl
wei_fh2 = t(wei_fh) %*% wei_fh
s_fout = c( 100*sqrt(c(wei_fl2)%*%c(se_f)), 100*sqrt(c(wei_fh2)%*%c(se_f)) )%>% as.data.frame()

b_s <- b_a
s_s <- sa_a

plt <- data.frame(matrix(ncol = 4, nrow = 9))
colnames(plt) <- c("firm_type", "worker_type", "b","se")
plt[1,] <- list("Low-paying"  ,"Low-paid"  , b_in[1,] , paste0("(",format(round(s_in[1,],3), nsmall = 3),")") )
plt[2,] <- list("High-paying" ,"Low-paid"  , b_in[2,] , paste0("(",format(round(s_in[2,],3), nsmall = 3),")") )
plt[3,] <- list("Low-paying"  ,"High-paid" , b_in[3,] , paste0("(",format(round(s_in[3,],3), nsmall = 3),")") )
plt[4,] <- list("High-paying" ,"High-paid" , b_in[4,] , paste0("(",format(round(s_in[4,],3), nsmall = 3),")") )
plt[5,] <- list("All" ,"Low-paid" , b_wout[1,] , paste0("(",format(round(s_wout[1,],3), nsmall = 3),")") )
plt[6,] <- list("All" ,"High-paid" , b_wout[2,] , paste0("(",format(round(s_wout[2,],3), nsmall = 3),")") )
plt[7,] <- list("All" ,"All" , b_s , paste0("(",format(round(s_s,3), nsmall = 3),")")  )
plt[8,] <- list("Low-paying"  ,"All"  , b_fout[1,] , paste0("(",format(round(s_fout[1,],3), nsmall = 3),")") )
plt[9,] <- list("High-paying"  ,"All"  , b_fout[2,] , paste0("(",format(round(s_fout[2,],3), nsmall = 3),")") )
plt$firm_type <- factor(plt$firm_type, levels = unique(as.character(plt[[1]])))
plt$worker_type <- factor(plt$worker_type, levels = unique(as.character(plt[[2]])))

htm <- ggplot(plt, aes(firm_type,worker_type, fill= b)) + 
  geom_tile(color = "black") +
  theme_minimal() +
  xlab("Firm type") +
  ylab("Worker type") +
  coord_fixed() + 
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_text(aes(label = format(round(b,3), nsmall = 3)), color = "white", size = 8, position = position_nudge(y = 0.1)) +
  geom_text(aes(label = se), color = "white", size = 6, position = position_nudge(y = -0.2)) +
  theme(legend.position = "none") +
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5, hjust = 0.5), legend.spacing.y = unit(0.7, 'cm')) +
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),plot.title = element_text(size = 19),panel.grid.minor = element_blank(),legend.title = element_text(size = 16),legend.text=element_text(size=16))
plot(htm)
ggsave(paste0("figure_a7_plot_panel_b.pdf"),path = figure_path,width = 8,height = 6)


## REALLOCATION


out_nm <- "figure_a7_panel_c_regression_3"
data_h <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_c_vcov_3"
vcov_h <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a7_panel_c_regression_2"
data_w <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_c_vcov_2"
vcov_w <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a7_panel_c_regression_1"
data_f <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_a7_panel_c_vcov_1"
vcov_f <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_3_regression"
data_a <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

b_a <- data9[6,2] * 100
sa_a <- data9[6,4] * 100

w_p_l <- 0
w_p_h <- 1
w_b_l <- 0
w_b_h <- 1

b_s <- data_h[1,4]
b_b <- data_h[1,7]
b_p <- data_h[1,8]
b_i <- data_h[1,9]

wei_wl_fl = c(1,w_p_l,w_b_l,(w_p_l*w_b_l)) %>% as.matrix()%>% t()
wei_wl_fh = c(1,w_p_l,w_b_h,(w_p_l*w_b_h)) %>% as.matrix()%>% t()
wei_wh_fl = c(1,w_p_h,w_b_l,(w_p_h*w_b_l)) %>% as.matrix()%>% t()
wei_wh_fh = c(1,w_p_h,w_b_h,(w_p_h*w_b_h)) %>% as.matrix()%>% t()

b = c(b_s,b_p,b_b,b_i) %>% as.matrix() %>% t()

se <- rbind(c(vcov_h[3,3],vcov_h[3,7],vcov_h[3,6],vcov_h[3,8]),c(vcov_h[7,3],vcov_h[7,7],vcov_h[7,6],vcov_h[7,8]),c(vcov_h[6,3],vcov_h[6,7],vcov_h[6,6],vcov_h[6,8]),c(vcov_h[8,3],vcov_h[8,7],vcov_h[8,6],vcov_h[8,8])) %>% as.matrix()

b_in = 100 * c( wei_wl_fl%*%t(b),wei_wl_fh%*%t(b),wei_wh_fl%*%t(b),wei_wh_fh%*%t(b)) %>% as.data.frame()

wei_wl_fl2 = t(wei_wl_fl) %*% wei_wl_fl
wei_wl_fh2 = t(wei_wl_fh) %*% wei_wl_fh
wei_wh_fl2 = t(wei_wh_fl) %*% wei_wh_fl
wei_wh_fh2 = t(wei_wh_fh) %*% wei_wh_fh

s_in = c( 100*sqrt(c(wei_wl_fl2)%*%c(se)), 100*sqrt(c(wei_wl_fh2)%*%c(se)), 100*sqrt(c(wei_wh_fl2)%*%c(se)), 100*sqrt(c(wei_wh_fh2)%*%c(se)) )%>% as.data.frame()


b_ws <- data_w[1,3]
b_wp <- data_w[1,5]
wei_wl = c(1,w_p_l) %>% as.matrix()%>% t()
wei_wh = c(1,w_p_h) %>% as.matrix()%>% t()
b_w = c(b_ws,b_wp) %>% as.matrix() %>% t()
se_w <- rbind(c(vcov_w[2,2],vcov_w[2,4]),c(vcov_w[4,2],vcov_w[4,4])) %>% as.matrix()
b_wout = 100 * c( wei_wl%*%t(b_w),wei_wh%*%t(b_w)) %>% as.data.frame()
wei_wl2 = t(wei_wl) %*% wei_wl
wei_wh2 = t(wei_wh) %*% wei_wh
s_wout = c( 100*sqrt(c(wei_wl2)%*%c(se_w)), 100*sqrt(c(wei_wh2)%*%c(se_w)) )%>% as.data.frame()

b_fs <- data_f[1,3]
b_fb <- data_f[1,5]
wei_fl = c(1,w_p_l) %>% as.matrix()%>% t()
wei_fh = c(1,w_p_h) %>% as.matrix()%>% t()
b_f = c(b_fs,b_fb) %>% as.matrix() %>% t()
se_f <- rbind(c(vcov_f[2,2],vcov_f[2,4]),c(vcov_f[4,2],vcov_f[4,4])) %>% as.matrix()
b_fout = 100 * c( wei_fl%*%t(b_f),wei_fh%*%t(b_f)) %>% as.data.frame()
wei_fl2 = t(wei_fl) %*% wei_fl
wei_fh2 = t(wei_fh) %*% wei_fh
s_fout = c( 100*sqrt(c(wei_fl2)%*%c(se_f)), 100*sqrt(c(wei_fh2)%*%c(se_f)) )%>% as.data.frame()

b_s <- b_a
s_s <- sa_a

plt <- data.frame(matrix(ncol = 4, nrow = 9))
colnames(plt) <- c("firm_type", "worker_type", "b","se")
plt[1,] <- list("Low-paying"  ,"Low-paid"  , b_in[1,] , paste0("(",format(round(s_in[1,],3), nsmall = 3),")") )
plt[2,] <- list("High-paying" ,"Low-paid"  , b_in[2,] , paste0("(",format(round(s_in[2,],3), nsmall = 3),")") )
plt[3,] <- list("Low-paying"  ,"High-paid" , b_in[3,] , paste0("(",format(round(s_in[3,],3), nsmall = 3),")") )
plt[4,] <- list("High-paying" ,"High-paid" , b_in[4,] , paste0("(",format(round(s_in[4,],3), nsmall = 3),")") )
plt[5,] <- list("All" ,"Low-paid" , b_wout[1,] , paste0("(",format(round(s_wout[1,],3), nsmall = 3),")") )
plt[6,] <- list("All" ,"High-paid" , b_wout[2,] , paste0("(",format(round(s_wout[2,],3), nsmall = 3),")") )
plt[7,] <- list("All" ,"All" , b_s , paste0("(",format(round(s_s,3), nsmall = 3),")")  )
plt[8,] <- list("Low-paying"  ,"All"  , b_fout[1,] , paste0("(",format(round(s_fout[1,],3), nsmall = 3),")") )
plt[9,] <- list("High-paying"  ,"All"  , b_fout[2,] , paste0("(",format(round(s_fout[2,],3), nsmall = 3),")") )
plt$firm_type <- factor(plt$firm_type, levels = unique(as.character(plt[[1]])))
plt$worker_type <- factor(plt$worker_type, levels = unique(as.character(plt[[2]])))

htm <- ggplot(plt, aes(firm_type,worker_type, fill= b)) + 
  geom_tile(color = "black") +
  theme_minimal() +
  xlab("Firm type") +
  ylab("Worker type") +
  coord_fixed() + 
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_text(aes(label = format(round(b,3), nsmall = 3)), color = "white", size = 8, position = position_nudge(y = 0.1)) +
  geom_text(aes(label = se), color = "white", size = 6, position = position_nudge(y = -0.2)) +
  theme(legend.position = "none") +
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5, hjust = 0.5), legend.spacing.y = unit(0.7, 'cm')) +
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),plot.title = element_text(size = 19),panel.grid.minor = element_blank(),legend.title = element_text(size = 16),legend.text=element_text(size=16))
plot(htm)
ggsave(paste0("figure_a7_plot_panel_c.pdf"),path = figure_path,width = 8,height = 6)

rm(list = ls())

library(ggplot2)
library(dplyr)

cd <-
figure_path   <- paste0(cd,"figures/")
data_path   <- paste0(cd,"outputs/") 

out_nm <- "figure_4_regression"
data <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()
out_nm <- "figure_4_vcov"
vcov <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,7]))),
                   s=as.vector(as.matrix(cbind(data[,15]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Firm Switching Probability (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.18,0.03),breaks=seq(-0.18,0.03,0.03), expand = c(0.01, 0.01), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_4_plot_panel_a.pdf"),path = figure_path,width = 8,height = 6)


rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,6]))),
                   s=as.vector(as.matrix(cbind(data[,14]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Firm Switching Probability (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.15,0.18),breaks=seq(-0.15,0.18,0.03), expand = c(0.01, 0.01), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_4_plot_panel_b.pdf"),path = figure_path,width = 8,height = 6)


rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,9]))),
                   s=as.vector(as.matrix(cbind(data[,17]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Firm Switching Probability (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.16,0.08),breaks=seq(-0.16,0.08,0.04), expand = c(0.001, 0.001), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_4_plot_panel_c.pdf"),path = figure_path,width = 8,height = 6)

p75_w <- 77.8321075439453
p50_w <- 53.5905570983887
p25_w <- 26.8823165893555
p75_f <- 87.3971786499023
p50_f <- 75.4283142089844
p25_f <- 39.7115898132324
sigma_w <- 29.1087501435049
sigma_f <- 27.0790734494494
w_p_l <- (p25_w-p50_w)/sigma_w
w_p_h <- (p75_w-p50_w)/sigma_w
w_b_l <- (p25_f-p50_f)/sigma_f
w_b_h <- (p75_f-p50_f)/sigma_f 

b_s <- data[6,2]
b_b <- data[6,6]
b_p <- data[6,7]
b_i <- data[6,9]

sig_s <- data[6,10]
sig_b <- data[6,14]
sig_p <- data[6,15]
sig_i <- data[6,17]
cov_s_p <- vcov[1,5]
cov_s_b <- vcov[1,6]
cov_s_i <- vcov[1,8]
cov_p_b <- vcov[5,6]
cov_p_i <- vcov[5,8]
cov_b_i <- vcov[6,8] 


wei_wl_fl = c(1,w_p_l,w_b_l,(w_p_l*w_b_l)) %>% as.matrix()%>% t()
wei_wl_fh = c(1,w_p_l,w_b_h,(w_p_l*w_b_h)) %>% as.matrix()%>% t()
wei_wh_fl = c(1,w_p_h,w_b_l,(w_p_h*w_b_l)) %>% as.matrix()%>% t()
wei_wh_fh = c(1,w_p_h,w_b_h,(w_p_h*w_b_h)) %>% as.matrix()%>% t()

b = c(b_s,b_p,b_b,b_i) %>% as.matrix() %>% t()

se <- rbind(c(vcov[1,1],vcov[1,6],vcov[1,5],vcov[1,8]),c(vcov[6,1],vcov[6,6],vcov[6,5],vcov[6,8]),c(vcov[5,1],vcov[5,6],vcov[5,5],vcov[5,8]),c(vcov[8,1],vcov[8,6],vcov[8,5],vcov[8,8])) %>% as.matrix()

b_in = 100 * c( wei_wl_fl%*%t(b),wei_wl_fh%*%t(b),wei_wh_fl%*%t(b),wei_wh_fh%*%t(b)) %>% as.data.frame()

wei_wl_fl2 = t(wei_wl_fl) %*% wei_wl_fl
wei_wl_fh2 = t(wei_wl_fh) %*% wei_wl_fh
wei_wh_fl2 = t(wei_wh_fl) %*% wei_wh_fl
wei_wh_fh2 = t(wei_wh_fh) %*% wei_wh_fh

s_in = c( 100*sqrt(c(wei_wl_fl2)%*%c(se)), 100*sqrt(c(wei_wl_fh2)%*%c(se)), 100*sqrt(c(wei_wh_fl2)%*%c(se)), 100*sqrt(c(wei_wh_fh2)%*%c(se)) )%>% as.data.frame()

wei_wl = c(1,w_p_l,0,0) %>% as.matrix()%>% t()
wei_wh = c(1,w_p_h,0,0) %>% as.matrix()%>% t()
wei_fl = c(1,0,w_b_l,0) %>% as.matrix()%>% t()
wei_fh = c(1,0,w_b_h,0) %>% as.matrix()%>% t()

b_out = 100 * c( wei_wl%*%t(b),wei_wh%*%t(b),wei_fl%*%t(b),wei_fh%*%t(b)) %>% as.data.frame()

wei_wl2 = t(wei_wl) %*% wei_wl
wei_wh2 = t(wei_wh) %*% wei_wh
wei_fl2 = t(wei_fl) %*% wei_fl
wei_fh2 = t(wei_fh) %*% wei_fh

s_out = c( 100*sqrt(c(wei_wl2)%*%c(se)), 100*sqrt(c(wei_wh2)%*%c(se)), 100*sqrt(c(wei_fl2)%*%c(se)), 100*sqrt(c(wei_fh2)%*%c(se)) )%>% as.data.frame()

b_s <- b_s * 100
s_s <- sig_s * 100

plt <- data.frame(matrix(ncol = 4, nrow = 9))
colnames(plt) <- c("firm_type", "worker_type", "b","se")
plt[1,] <- list("Low-paying"  ,"Low-paid"  , b_in[1,] , paste0("(",format(round(s_in[1,],3), nsmall = 3),")") )
plt[2,] <- list("High-paying" ,"Low-paid"  , b_in[2,] , paste0("(",format(round(s_in[2,],3), nsmall = 3),")") )
plt[3,] <- list("Low-paying"  ,"High-paid" , b_in[3,] , paste0("(",format(round(s_in[3,],3), nsmall = 3),")") )
plt[4,] <- list("High-paying" ,"High-paid" , b_in[4,] , paste0("(",format(round(s_in[4,],3), nsmall = 3),")") )
plt[5,] <- list("All" ,"Low-paid" , b_out[1,] , paste0("(",format(round(s_out[1,],3), nsmall = 3),")") )
plt[6,] <- list("All" ,"High-paid" , b_out[2,] , paste0("(",format(round(s_out[2,],3), nsmall = 3),")") )
plt[7,] <- list("All" ,"All" , b_s , paste0("(",format(round(s_s,3), nsmall = 3),")")  )
plt[8,] <- list("Low-paying"  ,"All"  , b_out[3,] , paste0("(",format(round(s_out[3,],3), nsmall = 3),")") )
plt[9,] <- list("High-paying"  ,"All"  , b_out[4,] , paste0("(",format(round(s_out[4,],3), nsmall = 3),")") )
plt$firm_type <- factor(plt$firm_type, levels = unique(as.character(plt[[1]])))
plt$worker_type <- factor(plt$worker_type, levels = unique(as.character(plt[[2]])))

htm <- ggplot(plt, aes(firm_type,worker_type, fill= b)) + 
  geom_tile(color = "black") +
  theme_minimal() +
  xlab("Firm type") +
  ylab("Worker type") +
  coord_fixed() + 
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_text(aes(label = format(round(b,3), nsmall = 3)), color = "white", size = 8, position = position_nudge(y = 0.1)) +
  geom_text(aes(label = se), color = "white", size = 6, position = position_nudge(y = -0.2)) +
  theme(legend.position = "none") +
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5, hjust = 0.5), legend.spacing.y = unit(0.7, 'cm')) +
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),plot.title = element_text(size = 19),panel.grid.minor = element_blank(),legend.title = element_text(size = 16),legend.text=element_text(size=16))
plot(htm)
ggsave(paste0("figure_4_plot_panel_d.pdf"),path = figure_path,width = 8,height = 6)
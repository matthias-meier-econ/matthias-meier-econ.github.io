rm(list = ls())

library(ggplot2)
library(dplyr)

cd <-
figure_path   <- paste0(cd,"figures/")
data_path   <- paste0(cd,"outputs/") 

out_nm <- "figure_a3_unconditional_average"
data1 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_wrk_lo"
data2 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_wrk_hi"
data3 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_frm_lo"
data4 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_frm_hi"
data5 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_wrk_lo_frm_lo"
data6 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_wrk_hi_frm_lo"
data7 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_wrk_lo_frm_hi"
data8 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

out_nm <- "figure_a3_unconditional_wrk_hi_frm_hi"
data9 <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

plt <- data.frame(matrix(ncol = 3, nrow = 9))
colnames(plt) <- c("firm_type", "worker_type", "b")
plt[1,] <- list("Low-paying"  ,"Low-paid"  , data6[6,2] )
plt[2,] <- list("High-paying" ,"Low-paid"  , data8[6,2] )
plt[3,] <- list("Low-paying"  ,"High-paid" , data7[6,2] )
plt[4,] <- list("High-paying" ,"High-paid" , data9[6,2] )
plt[5,] <- list("All" ,"Low-paid" , data2[6,2]  )
plt[6,] <- list("All" ,"High-paid", data3[6,2]  )
plt[7,] <- list("All" ,"All" , data1[6,2] )
plt[8,] <- list("Low-paying"  ,"All"  , data4[6,2]  )
plt[9,] <- list("High-paying"  ,"All" , data5[6,2]  )
plt$firm_type <- factor(plt$firm_type, levels = unique(as.character(plt[[1]])))
plt$worker_type <- factor(plt$worker_type, levels = unique(as.character(plt[[2]])))
plt$b <- as.numeric(plt$b)

htm <- ggplot(plt, aes(firm_type,worker_type)) + 
  geom_tile(color = "black", fill="white") +
  theme_minimal() +
  xlab("Firm type") +
  ylab("Worker type") +
  coord_fixed() + 
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_text(aes(label = format(round(b,3), nsmall = 3)), color = "black", size = 8, position = position_nudge(y = 0.0)) +
  #  geom_text(aes(label = se), color = "white", size = 6, position = position_nudge(y = -0.2)) +
  theme(legend.position = "none") +
  theme(axis.text.y = element_text(angle = 90, vjust = 0.5, hjust = 0.5), legend.spacing.y = unit(0.7, 'cm')) +
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),plot.title = element_text(size = 19),panel.grid.minor = element_blank(),legend.title = element_text(size = 16),legend.text=element_text(size=16))
plot(htm)
ggsave(paste0("figure_a3_plot.pdf"),path = figure_path,width = 8,height = 6)



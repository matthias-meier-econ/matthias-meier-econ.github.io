rm(list = ls())

library(ggplot2)
library(dplyr)

cd <-
figure_path   <- paste0(cd,"figures/")
data_path   <- paste0(cd,"outputs/") 

out_nm <- "figure_a8_regression_panel_a"
data <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,2]))),
                   s=as.vector(as.matrix(cbind(data[,4]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Employment (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.3,0.3),breaks=seq(-0.2,0.2,0.1), expand = c(0.01, 0.01), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_a8_plot_panel_a.pdf"),path = figure_path,width = 8,height = 6)



out_nm <- "figure_a8_regression_panel_b_c_d"
data <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,7]))),
                   s=as.vector(as.matrix(cbind(data[,15]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Employment (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.15,0.1),breaks=seq(-0.15,0.1,0.05), expand = c(0.01, 0.01), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_a8_plot_panel_b.pdf"),path = figure_path,width = 8,height = 6)


rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,6]))),
                   s=as.vector(as.matrix(cbind(data[,14]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Employment (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.08,0.06),breaks=seq(-0.08,0.06,0.02), expand = c(0.01, 0.01), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_a8_plot_panel_c.pdf"),path = figure_path,width = 8,height = 6)


rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,9]))),
                   s=as.vector(as.matrix(cbind(data[,17]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Employment (in p.p.)"
xl <- "Quarters after shock"
plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(y = b), size = 1.5, colour = 'blue') +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  scale_y_continuous(limits=c(-0.05,0.05),breaks=seq(-0.05,0.05,0.01), expand = c(0.001, 0.001), labels = scales::comma) +
  theme(legend.position=c(0.8,0.1), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_a8_plot_panel_d.pdf"),path = figure_path,width = 8,height = 6)
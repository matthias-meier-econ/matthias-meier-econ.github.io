rm(list = ls())

library(ggplot2)
library(dplyr)

cd <-
figure_path   <- paste0(cd,"figures/")
data_path   <- paste0(cd,"outputs/") 

out_nm <- "figure_a4_regression"
data <- readRDS(paste0(data_path,out_nm,".rds")) %>% as.data.frame()

rtos <- data.frame(h=rep(c(0,1,2,3,4,5,6,7,8,9,10,11,12),1),
                   b=as.vector(as.matrix(cbind(data[,2]))),
                   s=as.vector(as.matrix(cbind(data[,7]))))
rtos$h <- as.numeric(rtos$h)
rtos$b <- as.numeric(rtos$b)
rtos$s <- as.numeric(rtos$s)
rtos$b <- rtos$b * 100
rtos$s <- rtos$s * 100
rtos$ub <- rtos$b + 1.96*rtos$s
rtos$lb <- rtos$b - 1.96*rtos$s
rtos$ub0 <- rtos$b + 1*rtos$s
rtos$lb0 <- rtos$b - 1*rtos$s
yl <- "Employment (in p.p.)"
xl <- "Quarters after shock"

plt <- ggplot(data = rtos,aes( x = h , y = b )) +
  geom_line(aes(), colour = 'blue', size = 2) +
  geom_ribbon(aes(x = h, ymax = ub , ymin = lb ), fill="deepskyblue2", alpha=.3) +
  geom_ribbon(aes(x = h, ymax = ub0, ymin = lb0), fill="blue", alpha=.3) +
  xlab(xl) + ylab(yl) + 
  theme_minimal() +
  theme(panel.grid.minor.y = element_blank(),
        panel.grid = element_line(size = 0.2),
        axis.title.y = element_text(vjust = +4),
        axis.title.x = element_text(vjust = -2) ) +
  theme(plot.margin = margin(0.8,0.8,0.8,0.8, "cm")) +
  #geom_line(colour = 'black') + 
  geom_hline(yintercept=0,colour = 'black') + 
  scale_x_continuous(limits=c(0,12),breaks=seq(0,12,2), expand = c(0.005, 0.005)) +
  theme(legend.position=c(0.22,0.915), legend.title = element_blank(),legend.direction = "vertical")+
  theme(axis.text = element_text(size = 18),axis.title = element_text(size = 20),legend.text=element_text(size=19),panel.grid.minor = element_blank())
plot(plt)
ggsave(paste0("figure_a4_plot.pdf"),path = figure_path,width = 8,height = 6)
rm(list = ls())                                                                                                                           
library(dplyr)                                                                                                                            
library(haven)                                                                                                                            
library(foreign)                                                                                                                         
library(statar)                                                                                                                            
library(data.table)                                                                                                                        
library(statar)                                                                                                                            
library(zoo)                                                                                                                               
library(lubridate)                                                                                                                 
library(lfe)                                                                                                                               
library(parallel)                                                                                                                          
library(doParallel)                                                                                                                        
library(fixest)                                                                                                                           
library(tictoc)                                                                                                                           
library(tidyverse)                                                                                                                           
library(tidyr)                                                                                                                           

cd <-
data_path   <- cd
code_path   <- paste0(cd,"codes/")
result_path <- paste0(cd,"outputs/")

data <- readRDS(paste0(data_path,"dataMP_no_fill_revision.rds")) %>% as.data.table()
data <- subset(data,data$trend<85)
data <- data[ data$worker_age>=26 & data$worker_age<=60,]

data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data <- select(data, -c(quart) )
names(data)

stats <- data.frame(variable = rep(NA,11),
                    mean      = rep(NA,11), 
                    min     = rep(NA,11),
                    p25      = rep(NA,11),
                    p50      = rep(NA,11),
                    p75      = rep(NA,11),
                    max      = rep(NA,11),
                    sd       = rep(NA,11),
                    num      = rep(NA,11)
)

stats[1,]   <- c("employed",mean(data$empl,na.rm=T),min(data$empl,na.rm=T),quantile(data$empl,probs=c(0.25,0.5,0.75),na.rm=T),max(data$empl,na.rm=T),sd(data$empl,na.rm=T),sum(!is.na(data$empl)) ) %>% t()
stats[2,]   <- c("worker_age",mean(data$worker_age,na.rm=T),min(data$worker_age,na.rm=T),quantile(data$worker_age,probs=c(0.25,0.5,0.75),na.rm=T),max(data$worker_age,na.rm=T),sd(data$worker_age,na.rm=T),sum(!is.na(data$worker_age)) ) %>% t()
stats[3,]   <- c("dailyWage",mean(data$dailyWage,na.rm=T),min(data$dailyWage,na.rm=T),quantile(data$dailyWage,probs=c(0.25,0.5,0.75),na.rm=T),max(data$dailyWage,na.rm=T),sd(data$dailyWage,na.rm=T),sum(!is.na(data$dailyWage)) ) %>% t()


stats[7,]   <- c("firm_age",mean(data$firm_age,na.rm=T),min(data$firm_age,na.rm=T),quantile(data$firm_age,probs=c(0.25,0.5,0.75),na.rm=T),max(data$firm_age,na.rm=T),sd(data$firm_age,na.rm=T),sum(!is.na(data$firm_age)) ) %>% t()
stats[8,]   <- c("firm_size",mean(data$firm_size,na.rm=T),min(data$firm_size,na.rm=T),quantile(data$firm_size,probs=c(0.25,0.5,0.75),na.rm=T),max(data$firm_size,na.rm=T),sd(data$firm_size,na.rm=T),sum(!is.na(data$firm_size)) ) %>% t()

stats[9,]  <- c("benr_fe_const_standard",mean(data$benr_fe,na.rm=T),min(data$benr_fe,na.rm=T),quantile(data$benr_fe,probs=c(0.25,0.5,0.75),na.rm=T),max(data$benr_fe,na.rm=T),sd(data$benr_fe,na.rm=T),sum(!is.na(data$benr_fe)) ) %>% t()
stats[10,]  <- c("penr_fe_const_standard",mean(data$penr_fe,na.rm=T),min(data$penr_fe,na.rm=T),quantile(data$penr_fe,probs=c(0.25,0.5,0.75),na.rm=T),max(data$penr_fe,na.rm=T),sd(data$penr_fe,na.rm=T),sum(!is.na(data$penr_fe)) ) %>% t()

data <- data[with(data, order(penr, trend)), ]  
data <- setkey(data, penr, trend)
data[,b1 := data[list(penr,trend-1)][["benr"]]]
data[,t1 := data[list(penr,trend-1)][["empl"]]]

data$ee <- ifelse( data$benr!= data$b1 , 1, 0  )
data$ee <- ifelse( data$t1==0, NA, data$ee)
data$ee <- ifelse( is.na(data$t1)==T, NA, data$ee)
data$ee <- ifelse( data$t1==1 & data$empl==0 , 0, data$ee  )

data$eu <- ifelse( data$t1==1 & data$empl==0 , 1, 0  )
data$eu <- ifelse( is.na(data$t1)==T, NA, data$eu)
data$eu <- ifelse( data$t1==0, NA, data$eu)

data$ue <- ifelse( data$t1==0 & data$empl==1 , 1, 0  )
data$ue <- ifelse( is.na(data$t1)==T, NA, data$ue)
data$ue <- ifelse( data$t1==1, NA, data$ue)

stats[4,]  <- c("EE",mean(data$ee,na.rm=T),min(data$ee,na.rm=T),quantile(data$ee,probs=c(0.25,0.5,0.75),na.rm=T),max(data$ee,na.rm=T),sd(data$ee,na.rm=T),sum(!is.na(data$ee)) ) %>% t()
stats[5,]  <- c("EU",mean(data$eu,na.rm=T),min(data$eu,na.rm=T),quantile(data$eu,probs=c(0.25,0.5,0.75),na.rm=T),max(data$eu,na.rm=T),sd(data$eu,na.rm=T),sum(!is.na(data$eu)) ) %>% t()
stats[6,]  <- c("UE",mean(data$ue,na.rm=T),min(data$ue,na.rm=T),quantile(data$ue,probs=c(0.25,0.5,0.75),na.rm=T),max(data$ue,na.rm=T),sd(data$ue,na.rm=T),sum(!is.na(data$ue)) ) %>% t()

shocks <- read_dta(paste0(data_path,"shocks_quarterly_1999_2019.dta")) 

stats[11,]  <- c("Shock",mean(shocks$mps6_mq,na.rm=T),min(shocks$mps6_mq,na.rm=T),quantile(shocks$mps6_mq,probs=c(0.25,0.5,0.75),na.rm=T),max(shocks$mps6_mq,na.rm=T),sd(shocks$mps6_mq,na.rm=T),sum(!is.na(shocks$mps6_mq)) ) %>% t()

saveRDS(stats, file = paste0(result_path,"table_1_descriptives.rds"))

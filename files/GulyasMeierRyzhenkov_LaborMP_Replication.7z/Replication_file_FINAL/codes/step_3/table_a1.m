clc; clear all; close all


%% Data 

% Coefficient estimates
b = [-0.002977465	0.000690641	-0.000766815	0.000237653];
%    beta	        gamma_wrk	gamma_frm	    gamma_wrk/frm

% Covariance of estimates 
c = [ 4.88398E-07	-1.31798E-07	3.74318E-08	  2.06592E-08
     -1.31798E-07	 4.5297E-08	   -2.93521E-09	 -3.80494E-09
      3.74318E-08	-2.93521E-09	2.23636E-08	 -2.9954E-09
      2.06592E-08	-3.80494E-09   -2.9954E-09	  6.48532E-09];

% Quartiles of worker rank
pw = [0.268823166 0.535905571 0.778321075];
% Standard deviation of worker rank
sw = 0.291087501;
% Quartiles of firm rank
pf = [0.397115898 0.754283142 0.873971786];
% Standard deviation of firm rank
sf = 0.270790734;



%% Recover point estimates and s.e. for interior 2x2 matrix of Fig. 2(d) 

% weights for b vector: 
wll = [1 (pw(1)-pw(2))/sw (pf(1)-pf(2))/sf (pw(1)-pw(2))*(pf(1)-pf(2))/(sw*sf)]; % wrk low frm low
wlh = [1 (pw(1)-pw(2))/sw (pf(3)-pf(2))/sf (pw(1)-pw(2))*(pf(3)-pf(2))/(sw*sf)]; % wrk low frm high
whl = [1 (pw(3)-pw(2))/sw (pf(1)-pf(2))/sf (pw(3)-pw(2))*(pf(1)-pf(2))/(sw*sf)]; % wrk high frm low 
whh = [1 (pw(3)-pw(2))/sw (pf(3)-pf(2))/sf (pw(3)-pw(2))*(pf(3)-pf(2))/(sw*sf)]; % wrk high frm high

% point estimates of interior of Fig. 2(d)
pe = 100 * [wll * b', wlh * b', whl * b', whh * b'];
fprintf('%1.3f \t %1.3f  \t %1.3f  \t %1.3f \n', pe)

% s.e. of interior of Fig. 2(d)
% weights for c matrix: 
wll2 = wll' * wll; % wrk low frm low
wlh2 = wlh' * wlh; % wrk low frm high
whl2 = whl' * whl; % wrk high frm low 
whh2 = whh' * whh; % wrk high frm high
se = 100 * sqrt([wll2(:)' * c(:), wlh2(:)' * c(:), whl2(:)' * c(:), whh2(:)' * c(:)]);
fprintf('%1.3f \t %1.3f  \t %1.3f  \t %1.3f \n\n', se)



%% Test differences for interior 2x2 matrix of Fig. 2(d)  

% Difference between:  
% wrk low frm low VS wrk low frm high
auxw  = wll'*(-wlh);
auxc  = auxw(:)' * c(:);
dff_c = (se(1)/100)^2 + (se(2)/100)^2 + 2 * auxc;
dff_b = pe(1)/100 - pe(2)/100;
test_lllh = dff_b / sqrt(dff_c);

% wrk low frm low VS wrk high frm low
auxw  = wll'*(-whl);
auxc  = auxw(:)' * c(:);
dff_c = (se(1)/100)^2 + (se(3)/100)^2 + 2 * auxc;
dff_b = pe(1)/100 - pe(3)/100;
test_llhl = dff_b / sqrt(dff_c);

% wrk low frm low VS wrk high frm high
auxw  = wll'*(-whh);
auxc  = auxw(:)' * c(:);
dff_c = (se(1)/100)^2 + (se(4)/100)^2 + 2 * auxc;
dff_b = pe(1)/100 - pe(4)/100;
test_llhh = dff_b / sqrt(dff_c);

% wrk low frm high VS wrk high frm low
auxw  = wlh'*(-whl);
auxc  = auxw(:)' * c(:);
dff_c = (se(2)/100)^2 + (se(3)/100)^2 + 2 * auxc;
dff_b = pe(2)/100 - pe(3)/100;
test_lhhl = dff_b / sqrt(dff_c);

% wrk low frm high VS wrk high frm hig
auxw  = wlh'*(-whh);
auxc  = auxw(:)' * c(:);
dff_c = (se(2)/100)^2 + (se(4)/100)^2 + 2 * auxc;
dff_b = pe(2)/100 - pe(4)/100;
test_lhhh = dff_b / sqrt(dff_c);

% wrk high frm low VS wrk high frm hig
auxw  = whl'*(-whh);
auxc  = auxw(:)' * c(:);
dff_c = (se(3)/100)^2 + (se(4)/100)^2 + 2 * auxc;
dff_b = pe(3)/100 - pe(4)/100;
test_hlhh = dff_b / sqrt(dff_c);

fprintf('%1.3f \t %1.3f \t %1.3f \t %1.3f \t %1.3f \t %1.3f \n\n', ...
        [test_lllh, test_llhl, test_llhh, test_lhhl, test_lhhh, test_hlhh])

%%% Result of tests

% 1% significant
% lllh, lhhl, lhhh, hlhh


% 10% insignificant
% llhl, llhh






%% Recover point estimates and s.e. for exterior 2x2 matrix of Fig. 2(d) 

% weights for b vector: 
wl0 = [1 (pw(1)-pw(2))/sw 0 0]; % wrk low 
wh0 = [1 (pw(3)-pw(2))/sw 0 0]; % wrk high 
w0l = [1 0 (pf(1)-pf(2))/sf 0]; % frm low
w0h = [1 0 (pf(3)-pf(2))/sf 0]; % frm high

% point estimates of exterior of Fig. 2(d)
pe = 100 * [wl0 * b', wh0 * b', w0l * b', w0h * b'];
fprintf('%1.3f \t %1.3f  \t %1.3f  \t %1.3f \n', pe)

% s.e. of exterior of Fig. 2(d)
% weights for c matrix: 
wl02 = wl0'*wl0; % wrk low 
wh02 = wh0'*wh0; % wrk high
w0l2 = w0l'*w0l; % frm low 
w0h2 = w0h'*w0h; % frm high
se = 100 * sqrt([wl02(:)' * c(:), wh02(:)' * c(:), w0l2(:)' * c(:), w0h2(:)' * c(:)]);
fprintf('%1.3f \t %1.3f  \t %1.3f  \t %1.3f \n\n', se)



%% Test differences for exterior of 2x2 matrix of Fig. 2(d)  

% Difference between:  
% wrk low VS wrk high
auxw  = wl0'*(-wh0);
auxc  = auxw(:)' * c(:);
dff_c = (se(1)/100)^2 + (se(2)/100)^2 + 2 * auxc;
dff_b = pe(1)/100 - pe(2)/100;
test_l0h0 = dff_b / sqrt(dff_c);

% frm low VS frm high 
auxw  = w0l'*(-w0h);
auxc  = auxw(:)' * c(:);
dff_c = (se(3)/100)^2 + (se(4)/100)^2 + 2 * auxc;
dff_b = pe(3)/100 - pe(4)/100;
test_0l0h = dff_b / sqrt(dff_c);

fprintf('%1.3f \t %1.3f \n\n', ...
        [test_l0h0, test_0l0h])

%%% Result of tests

% 1% significant
% l0h0, 0l0h




